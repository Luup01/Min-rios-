package dev.atlasgeologia;

/** Um disco mineral (lente 3D): elipse no plano (u,v) com perfil de espessura ao longo da normal n. Imutavel. */
public final class Disc {
    public final double cx, cy, cz, a, b, T, az, dip, conc, irr;
    public final long seed;
    // derivados (identicos ao reference python: deposit_field.py)
    public final double ux, uy, uz, vx, vy, vz, nx, ny, nz, ls, ls2, hmaxT;
    public final int x0, x1, y0, y1, z0, z1;   // caixa inteira inclusiva

    public Disc(double cx, double cy, double cz, double a, double b, double T, double az, double dip,
                double conc, double irr, long seed) {
        this.cx = cx; this.cy = cy; this.cz = cz; this.a = a; this.b = b; this.T = T;
        this.az = az; this.dip = dip; this.conc = conc; this.irr = irr; this.seed = seed;
        double azr = az * (Math.PI / 180.0), dpr = dip * (Math.PI / 180.0);
        double c = StrictMath.cos(azr), s = StrictMath.sin(azr), cd = StrictMath.cos(dpr), sd = StrictMath.sin(dpr);
        ux = c; uy = 0.0; uz = s;
        vx = -s * cd; vy = -sd; vz = c * cd;
        nx = s * sd; ny = -cd; nz = -c * sd;
        double l = Math.max(3.0, 0.18 * Math.min(a, b));
        this.ls = l; this.ls2 = l * 1.7;
        double hmax = 0.5 * T * (1.0 + DepositField.THICK_AMP * irr) + 1.0;
        this.hmaxT = hmax;
        double R = DepositField.EDGE_REACH;
        double ex = Math.sqrt(sq(R * a * ux) + sq(R * b * vx)) + hmax * Math.abs(nx) + 1.0;
        double ey = Math.sqrt(sq(R * a * uy) + sq(R * b * vy)) + hmax * Math.abs(ny) + 1.0;
        double ez = Math.sqrt(sq(R * a * uz) + sq(R * b * vz)) + hmax * Math.abs(nz) + 1.0;
        x0 = (int) Math.floor(cx - ex); x1 = (int) Math.ceil(cx + ex);
        y0 = (int) Math.floor(cy - ey); y1 = (int) Math.ceil(cy + ey);
        z0 = (int) Math.floor(cz - ez); z1 = (int) Math.ceil(cz + ez);
    }

    private static double sq(double v) { return v * v; }
}
