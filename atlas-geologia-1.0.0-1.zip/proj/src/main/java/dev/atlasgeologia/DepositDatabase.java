package dev.atlasgeologia;

import java.io.*;
import java.util.*;

/**
 * Banco imutavel de depositos pre-calculados (deposits.bin) com indice espacial em grade de 64x64 blocos.
 * Consultar um chunk custa O(depositos vizinhos) - o planeta inteiro nunca e varrido.
 */
public final class DepositDatabase {
    public static final int CELL_SHIFT = 6;

    public final String[] oreKeys, oreStoneIds, oreDeepIds, typeNames;
    public final Deposit[] deposits;
    public final int discCount;
    private final HashMap<Long, int[]> grid;

    private DepositDatabase(String[] k, String[] s, String[] d, String[] t, Deposit[] deps, int discs, HashMap<Long, int[]> grid) {
        this.oreKeys = k; this.oreStoneIds = s; this.oreDeepIds = d; this.typeNames = t;
        this.deposits = deps; this.discCount = discs; this.grid = grid;
    }

    private static String readStr(DataInputStream in) throws IOException {
        int n = in.readUnsignedShort(); byte[] b = new byte[n]; in.readFully(b); return new String(b, "UTF-8");
    }

    public static DepositDatabase load(InputStream raw) throws IOException {
        DataInputStream in = new DataInputStream(new BufferedInputStream(raw, 1 << 16));
        byte[] magic = new byte[4]; in.readFully(magic);
        if (!"ATGD".equals(new String(magic, "US-ASCII"))) throw new IOException("deposits.bin invalido (magic)");
        int version = in.readInt(); if (version != 1) throw new IOException("versao nao suportada: " + version);
        int nDep = in.readInt(), nDisc = in.readInt();
        int nOre = in.readInt();
        String[] keys = new String[nOre], stone = new String[nOre], deep = new String[nOre];
        for (int i = 0; i < nOre; i++) { keys[i] = readStr(in); stone[i] = readStr(in); deep[i] = readStr(in); }
        int nType = in.readInt(); String[] types = new String[nType];
        for (int i = 0; i < nType; i++) types[i] = readStr(in);
        Deposit[] deps = new Deposit[nDep];
        for (int i = 0; i < nDep; i++) {
            int id = in.readInt(); int ore = in.readUnsignedByte(); int ao = in.readUnsignedByte();
            int scale = in.readUnsignedByte(); int type = in.readUnsignedByte(); int prov = in.readUnsignedByte();
            int minDepth = in.readUnsignedByte(); double af = in.readDouble();
            int nd = in.readUnsignedShort(); Disc[] ds = new Disc[nd];
            for (int k = 0; k < nd; k++) {
                double cx = in.readDouble(), cy = in.readDouble(), cz = in.readDouble(), a = in.readDouble(), b = in.readDouble(),
                        T = in.readDouble(), az = in.readDouble(), dip = in.readDouble(), conc = in.readDouble(), irr = in.readDouble();
                long seed = in.readLong();
                ds[k] = new Disc(cx, cy, cz, a, b, T, az, dip, conc, irr, seed);
            }
            deps[i] = new Deposit(id, ore, ao == 255 ? -1 : ao, scale, type, prov, minDepth, af, ds);
        }
        // indice espacial
        HashMap<Long, ArrayList<Integer>> tmp = new HashMap<>();
        for (int i = 0; i < nDep; i++) {
            Deposit d = deps[i];
            for (int cx = d.minX >> CELL_SHIFT; cx <= d.maxX >> CELL_SHIFT; cx++)
                for (int cz = d.minZ >> CELL_SHIFT; cz <= d.maxZ >> CELL_SHIFT; cz++)
                    tmp.computeIfAbsent(key(cx, cz), q -> new ArrayList<>()).add(i);
        }
        HashMap<Long, int[]> g = new HashMap<>(tmp.size() * 2);
        for (Map.Entry<Long, ArrayList<Integer>> e : tmp.entrySet()) {
            int[] arr = new int[e.getValue().size()]; for (int i = 0; i < arr.length; i++) arr[i] = e.getValue().get(i);
            g.put(e.getKey(), arr);
        }
        return new DepositDatabase(keys, stone, deep, types, deps, nDisc, g);
    }

    private static long key(int cx, int cz) { return ((long) cx << 32) ^ (cz & 0xFFFFFFFFL); }

    /** depositos cuja caixa intersecta o retangulo [x0,x1]x[z0,z1], em ordem crescente de indice (deterministico). */
    public List<Deposit> query(int x0, int z0, int x1, int z1) {
        TreeSet<Integer> set = new TreeSet<>();
        for (int cx = x0 >> CELL_SHIFT; cx <= x1 >> CELL_SHIFT; cx++)
            for (int cz = z0 >> CELL_SHIFT; cz <= z1 >> CELL_SHIFT; cz++) {
                int[] a = grid.get(key(cx, cz));
                if (a != null) for (int i : a) set.add(i);
            }
        ArrayList<Deposit> out = new ArrayList<>(set.size());
        for (int i : set) {
            Deposit d = deposits[i];
            if (d.maxX >= x0 && d.minX <= x1 && d.maxZ >= z0 && d.minZ <= z1) out.add(d);
        }
        return out;
    }
}
