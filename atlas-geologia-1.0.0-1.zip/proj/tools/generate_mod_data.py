"""
GERADOR DE DADOS DO MOD (equivalente aos "data generators"): copia o banco pre-calculado para os recursos do mod
e escreve os JSON de worldgen (configured_feature / placed_feature). Rode depois de build_deposits.py.
"""
import json, os, shutil
from atlas_common import OUT, ROOT
res = os.path.join(ROOT, "src/main/resources/data/atlas_geologia")
os.makedirs(os.path.join(res, "worldgen/configured_feature"), exist_ok=True)
os.makedirs(os.path.join(res, "worldgen/placed_feature"), exist_ok=True)
shutil.copy(os.path.join(OUT, "deposits.bin"), os.path.join(res, "deposits.bin"))
json.dump({"type": "atlas_geologia:mineral_deposits", "config": {}}, open(os.path.join(res, "worldgen/configured_feature/mineral_deposits.json"), "w"), indent=2)
json.dump({"feature": "atlas_geologia:mineral_deposits", "placement": []}, open(os.path.join(res, "worldgen/placed_feature/mineral_deposits.json"), "w"), indent=2)
print("recursos do mod atualizados")
