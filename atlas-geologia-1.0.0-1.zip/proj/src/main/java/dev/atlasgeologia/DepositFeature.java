package dev.atlasgeologia;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import java.util.List;

/**
 * Executada UMA vez por chunk (origin = canto minimo do chunk). Escreve somente blocos DENTRO do chunk atual,
 * avaliando a funcao voxel dos depositos vizinhos => sem costuras, sem dependencia da ordem de geracao.
 */
public class DepositFeature extends Feature<NoneFeatureConfiguration> {
    public DepositFeature(Codec<NoneFeatureConfiguration> codec) { super(codec); }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        AtlasConfig cfg = AtlasConfig.get();
        if (!cfg.enabled) return false;
        WorldGenLevel level = ctx.level();
        if (!dimensionAllowed(level, cfg)) return false;
        DepositDatabase db = AtlasGeologia.database();
        if (db == null) return false;

        BlockPos origin = ctx.origin();
        int cx0 = origin.getX() & ~15, cz0 = origin.getZ() & ~15;
        List<Deposit> list = db.query(cx0, cz0, cx0 + 15, cz0 + 15);
        if (list.isEmpty()) return false;

        int minY = level.getMinBuildHeight(), maxY = level.getMaxBuildHeight() - 1;
        int[] top = new int[256];
        for (int dz = 0; dz < 16; dz++)
            for (int dx = 0; dx < 16; dx++)
                top[dz * 16 + dx] = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, cx0 + dx, cz0 + dz) - 1;   // topo solido do terreno

        final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        final boolean[] placed = {false};
        final double scale = cfg.concentration_scale;
        for (Deposit dep : list) {
            final int minDepth = dep.minDepth;
            DepositField.forEachHit(dep, cx0, cx0 + 15, cz0, cz0 + 15, minY, maxY, scale, (x, y, z, ore) -> {
                if (y > top[(z - cz0) * 16 + (x - cx0)] - minDepth) return;            // nao rompe a superficie (alem do permitido)
                pos.set(x, y, z);
                BlockState host = level.getBlockState(pos);
                boolean stone = host.is(BlockTags.STONE_ORE_REPLACEABLES);
                boolean deep = !stone && host.is(BlockTags.DEEPSLATE_ORE_REPLACEABLES);
                if (!stone && !deep) return;                                              // so substitui rocha hospedeira
                level.setBlock(pos, AtlasGeologia.oreState(ore, deep), 2);
                placed[0] = true;
            });
        }
        return placed[0];
    }

    private static boolean dimensionAllowed(WorldGenLevel level, AtlasConfig cfg) {
        String id = level.getLevel().dimension().location().toString();
        if (!cfg.dimensions.isEmpty()) return cfg.dimensions.contains(id);
        return !level.dimensionType().hasCeiling() && !id.equals("minecraft:the_end");
    }
}
