"""
ETAPA 6-7: calcula TODA a distribuicao mineral a partir do modelo geologico e REGISTRA os depositos.
Saidas (a unica fonte de verdade, usada tanto pelas imagens quanto pelo mod):
  out/deposits.json   |  out/deposits.bin  |  out/districts.json  |  out/stats.json
Determinismo: todas as aleatoriedades derivam de MASTER_SEED (np.random.default_rng com seeds fixas).
"""
import json, math, struct, hashlib
import numpy as np
import cv2
from scipy import ndimage as ndi
from atlas_common import *
from deposit_field import *

MASTER_SEED = 20260930
G = 4
GH, GW = H // G, W // G

# ----------------------------------------------------------------------------------------------
ORES = {  # ids reais (vanilla 1.20.1 / presentes na config do Ore Veins)
    "coal":     dict(num=0, stone="minecraft:coal_ore",     deep="minecraft:deepslate_coal_ore",     color=(55, 55, 60),    per_chunk=90, band=(-10, 150), depth=[.40, .40, .18, .02]),
    "iron":     dict(num=1, stone="minecraft:iron_ore",     deep="minecraft:deepslate_iron_ore",     color=(235, 130, 60),  per_chunk=60, band=(-60, 130), depth=[.20, .40, .30, .10]),
    "copper":   dict(num=2, stone="minecraft:copper_ore",   deep="minecraft:deepslate_copper_ore",   color=(20, 200, 140),  per_chunk=40, band=(-40, 120), depth=[.15, .40, .35, .10]),
    "gold":     dict(num=3, stone="minecraft:gold_ore",     deep="minecraft:deepslate_gold_ore",     color=(255, 215, 0),   per_chunk=10, band=(-62, 90),  depth=[.08, .30, .40, .22]),
    "redstone": dict(num=4, stone="minecraft:redstone_ore", deep="minecraft:deepslate_redstone_ore", color=(230, 20, 30),   per_chunk=18, band=(-62, 40),  depth=[.03, .20, .40, .37]),
    "lapis":    dict(num=5, stone="minecraft:lapis_ore",    deep="minecraft:deepslate_lapis_ore",    color=(40, 70, 255),   per_chunk=7,  band=(-62, 70),  depth=[.05, .30, .45, .20]),
    "diamond":  dict(num=6, stone="minecraft:diamond_ore",  deep="minecraft:deepslate_diamond_ore",  color=(0, 235, 255),   per_chunk=3.5, band=(-62, 12), depth=[.00, .05, .40, .55]),
    "quartz":   dict(num=7, stone="minecraft:nether_quartz_ore", deep="minecraft:nether_quartz_ore",  color=(225, 60, 250),  per_chunk=14, band=(-40, 170), depth=[.30, .35, .25, .10]),
}
ORE_LIST = sorted(ORES, key=lambda k: ORES[k]["num"])
DEPTH_RANGES = [(4, 24), (24, 64), (64, 120), (120, 220)]
DEPTH_NAMES = ["superficial", "intermediario", "profundo", "extremamente_profundo"]

SCALES = ["small", "medium", "large", "mega"]
SIZE = {  # semi-eixo a (blocos), espessura total no nucleo T
    "small": dict(a=(3.5, 7.0), T=(2.0, 3.4), conc=0.55),
    "medium": dict(a=(8.0, 17.0), T=(3.0, 6.0), conc=0.60),
    "large": dict(a=(24.0, 46.0), T=(6.0, 12.0), conc=0.66),
    "mega": dict(a=(60.0, 105.0), T=(13.0, 26.0), conc=0.74),
}
SHARE = {"small": 0.22, "medium": 0.40, "large": 0.38}       # fracao do orcamento do minerio (exceto megas)
MEGA = {  # n, volume alvo (blocos de minerio) por mega deposito
    "coal": (3, 160000), "iron": (3, 140000), "copper": (3, 110000), "gold": (2, 36000),
    "redstone": (2, 45000), "lapis": (2, 30000), "diamond": (2, 14000), "quartz": (3, 70000)}
MEGA_TYPE = {"coal": "coal_seam", "iron": "banded_iron_formation", "copper": "porphyry_stockwork",
             "gold": "orogenic_quartz_gold_vein", "redstone": "hydrothermal_lens", "lapis": "contact_metamorphic_lens",
             "diamond": "kimberlite_pipe", "quartz": "quartz_reef"}

TYPES = {  # dip(graus), aspecto b/a, fator espessura, layout, (assoc_ore, frac)
    "coal_seam": ((0, 10), (0.8, 1.4), 0.7, "chain", None),
    "offshore_coal_seam": ((0, 10), (0.8, 1.4), 0.7, "chain", None),
    "coal_lens": ((0, 18), (0.6, 1.0), 0.9, "cluster", None),
    "vms_sulfide_lens": ((0, 25), (0.6, 1.0), 1.2, "cluster", ("quartz", 0.10)),
    "banded_iron_formation": ((5, 28), (0.5, 1.2), 1.0, "chain", ("quartz", 0.15)),
    "hematite_lens": ((10, 45), (0.5, 0.9), 1.2, "cluster", None),
    "bog_iron_lens": ((0, 10), (0.7, 1.2), 0.6, "cluster", None),
    "porphyry_stockwork": ((35, 80), (0.7, 1.0), 1.5, "stack_fan", ("quartz", 0.15)),
    "oxidized_copper_blanket": ((0, 15), (0.8, 1.3), 0.8, "cluster", None),
    "sediment_hosted_copper": ((0, 12), (0.8, 1.4), 0.7, "chain", None),
    "orogenic_quartz_gold_vein": ((55, 88), (0.30, 0.55), 0.6, "chain", ("quartz", 0.40)),
    "epithermal_vein": ((60, 90), (0.25, 0.50), 0.5, "fan", ("quartz", 0.30)),
    "greenstone_lode": ((40, 80), (0.35, 0.60), 0.7, "chain", ("quartz", 0.25)),
    "paleoplacer_lens": ((0, 8), (0.6, 1.0), 0.5, "chain", None),
    "skarn_lens": ((20, 70), (0.6, 1.0), 1.0, "cluster", ("quartz", 0.10)),
    "hydrothermal_lens": ((25, 75), (0.5, 0.9), 0.9, "fan", ("quartz", 0.20)),
    "contact_metamorphic_lens": ((25, 70), (0.4, 0.8), 0.8, "chain", None),
    "kimberlite_pipe": ((0, 22), (0.9, 1.1), 1.0, "pipe", None),
    "hydrothermal_quartz_vein": ((60, 88), (0.25, 0.50), 0.8, "chain", None),
    "volcanic_silica_lens": ((15, 60), (0.6, 1.0), 1.0, "cluster", None),
    "pegmatite_lens": ((15, 70), (0.5, 0.9), 1.3, "cluster", None),
    "seafloor_chert_lens": ((0, 20), (0.8, 1.2), 0.7, "cluster", None),
    "quartz_reef": ((60, 85), (0.20, 0.40), 1.1, "chain", None),
}

# coeficientes de afinidade por campo geologico
AFF = {
    "coal":     dict(sed=1.0, humid=0.45, coastal=0.25, shelf=0.07, shield=0.10, base=0.06),
    "iron":     dict(craton=0.9, shield=0.8, front=0.35, O=0.35, arid=0.5, sed=0.3, mor=0.55, shelf=0.03, base=0.18),
    "copper":   dict(volc=1.0, O=0.65, mor=0.8, arid=0.45, fault=0.45, sed=0.2, shelf=0.03, base=0.07),
    "gold":     dict(fault=0.95, volc=0.65, O=0.5, shield=0.45, craton=0.25, arid=0.2, front=0.3, mor=0.2, shelf=0.015, base=0.04),
    "redstone": dict(volc=0.85, contact=0.75, fault=0.35, O=0.3, mor=0.3, shelf=0.01, base=0.04),
    "lapis":    dict(contact=1.0, front=0.8, O=0.4, shield=0.25, shelf=0.01, base=0.03),
    "diamond":  dict(craton=1.0, shield=0.45, base=0.0),
    "quartz":   dict(O=0.9, fault=0.8, volc=0.75, contact=0.45, shield=0.4, front=0.3, mor=0.4, craton=0.15, shelf=0.03, base=0.08),
}

# assinaturas minerais regionais (distritos metalogenicos)
SIGS = [
    dict(name="Cinturao porfiritico Cu-Au-quartzo", f=lambda F: F["volc"] * 0.8 + F["O"] * 0.6, land=True, n=6, R=(90, 200), m=(1.5, 3.2),
         w=dict(copper=2.6, gold=1.6, quartz=1.4, redstone=0.6)),
    dict(name="Cinturao ferrifero (BIF) e greenstone", f=lambda F: F["craton"] + 0.9 * F["shield"], land=True, n=7, R=(110, 260), m=(1.5, 3.0),
         w=dict(iron=2.8, gold=1.0, quartz=0.8)),
    dict(name="Provincia kimberlitica", f=lambda F: F["craton"] * smooth01(F["dcoast"], 60, 200), land=True, n=3, R=(70, 140), m=(2.5, 4.5),
         w=dict(diamond=5.0, iron=0.8, quartz=0.6)),
    dict(name="Bacia carbonifera", f=lambda F: F["sed"] * (1 - F["O"]), land=True, n=8, R=(90, 240), m=(1.5, 3.2),
         w=dict(coal=3.0, iron=0.6, copper=0.4)),
    dict(name="Distrito hidrotermal de falha", f=lambda F: F["fault"] * (0.4 + F["O"] + F["volc"]), land=True, n=8, R=(60, 150), m=(1.5, 3.5),
         w=dict(gold=2.6, quartz=3.0, redstone=0.8, lapis=0.5)),
    dict(name="Aureola de contato metamorfico", f=lambda F: F["contact"] * (0.3 + F["O"] + F["front"]), land=True, n=6, R=(60, 130), m=(1.5, 3.2),
         w=dict(lapis=3.2, redstone=2.0, quartz=0.8)),
    dict(name="Planalto arido oxidado / epitermal", f=lambda F: F["arid"] * (1 - F["O"]), land=True, n=5, R=(80, 190), m=(1.3, 2.6),
         w=dict(copper=1.8, gold=1.6, iron=1.4, redstone=0.7)),
    dict(name="Sulfetos macicos de dorsal oceanica (VMS)", f=lambda F: F["mor"], land=False, n=7, R=(60, 170), m=(1.5, 3.5),
         w=dict(copper=2.6, iron=2.0, gold=0.8, quartz=0.8)),
    dict(name="Plataforma carbonifera offshore", f=lambda F: F["shelf"] * smooth01(F["dland"], 10, 60) * (1 - F["mor"]), land=False, n=5, R=(100, 220), m=(1.4, 2.4),
         w=dict(coal=2.0)),
    dict(name="Escudo glacial: ferro-ouro-quartzo", f=lambda F: F["shield"], land=True, n=5, R=(100, 220), m=(1.3, 2.4),
         w=dict(iron=1.8, gold=0.9, quartz=1.6, diamond=0.6, lapis=0.5)),
]


def smooth01(x, a, b):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def mixseed(*vals):
    h = hashlib.blake2b(repr(vals).encode(), digest_size=8).digest()
    return int.from_bytes(h, "little") & 0x7FFFFFFFFFFFFFFF


def smooth_noise(seed, sigma):
    rng = np.random.default_rng(seed)
    n = ndi.gaussian_filter(rng.standard_normal((GH, GW)), sigma, mode="reflect")
    return n / n.std()


# ----------------------------------------------------------------------------------------------
def load_fields():
    g = np.load(os.path.join(OUT, "geology.npz"))
    F = {k: g[k] for k in g.files}
    land = F["land"]
    F["volc"] = F["volcanic"]; F["sed"] = F["sedbasin"]
    F["fault"] = np.exp(-F["dfault"] / 80.0)
    F["contact"] = np.exp(-F["dcontact"] / 60.0) * land
    F["front"] = np.exp(-F["dfront"] / 60.0) * land
    F["shelf"] = F["shelf"].astype(np.float32)
    F["base"] = np.where(land, 1.0, 0.0).astype(np.float32)
    F["abyss"] = F["abyss"]
    st = json.load(open(os.path.join(OUT, "structures.json")))
    # raster de azimute da falha mais proxima
    lab = np.zeros((GH, GW), np.int32); az = [0.0]
    for k, f in enumerate(st["faults"]):
        cv2.line(lab, (int((f["x1"] + HALF_X) / G), int((f["z1"] + HALF_Z) / G)),
                 (int((f["x2"] + HALF_X) / G), int((f["z2"] + HALF_Z) / G)), k + 1, 1)
        az.append(math.degrees(math.atan2(f["z2"] - f["z1"], f["x2"] - f["x1"])))
    d, (ii, jj) = ndi.distance_transform_edt(lab == 0, return_indices=True)
    F["fault_az"] = np.array(az)[lab[ii, jj]]
    return F, st


def affinity(ore, F):
    A = np.zeros((GH, GW))
    for k, c in AFF[ore].items():
        A += c * F[k]
    A += 0.003 * F["abyss"] * (ore != "diamond")
    if ore == "coal":
        A *= (1 - 0.8 * F["O"]) * (1 - 0.7 * F["volc"])
    return np.power(np.clip(A, 0, None), 1.25)


def build_districts(F, rng):
    gx_, gz_ = np.meshgrid(np.arange(GW), np.arange(GH))
    X = gx_ * G + 2.0 - HALF_X; Z = gz_ * G + 2.0 - HALF_Z
    out = []
    for si, s in enumerate(SIGS):
        S = np.clip(s["f"](F), 0, None) * (F["land"] if s["land"] else ~F["land"])
        S = ndi.gaussian_filter(S, 4)
        if S.max() <= 0: continue
        S = S / S.max()
        P = S ** 2.0; chosen = 0; tries = 0
        while chosen < s["n"] and tries < 200 and P.sum() > 0:
            tries += 1
            k = rng.choice(P.size, p=(P / P.sum()).ravel())
            i, j = divmod(k, GW)
            cx, cz = float(X[i, j]), float(Z[i, j])
            if any(math.hypot(cx - d["cx"], cz - d["cz"]) < 200 for d in out if d["sig"] == si): 
                P[max(i - 3, 0):i + 4, max(j - 3, 0):j + 4] = 0; continue
            out.append(dict(sig=si, name=s["name"], cx=cx, cz=cz, R=float(rng.uniform(*s["R"])), m=float(rng.uniform(*s["m"])),
                            w=s["w"], score=float(S[i, j])))
            chosen += 1
    return out, X, Z


def make_boost(ore, districts, X, Z):
    B = np.ones((GH, GW))
    for d in districts:
        w = d["w"].get(ore, 0)
        if w <= 0: continue
        r2 = ((X - d["cx"]) ** 2 + (Z - d["cz"]) ** 2) / d["R"] ** 2
        B += d["m"] * w * np.exp(-r2)
    return B


def regional_modulation(ore, num):
    n = 0.75 * smooth_noise(mixseed("mod_large", ore), 70) + 0.55 * smooth_noise(mixseed("mod_mid", ore), 22)
    n /= n.std()
    s = 0.95
    return np.exp(s * n - 0.5 * s * s)


# ----------------------------------------------------------------------------------------------
def est_volume(discs):
    v = 0.0
    for d in discs:
        v += 1.339 * d["conc"] * d["a"] * d["b"] * d["T"]
    return v


def cell_at(x, z):
    return int(np.clip((z + HALF_Z) // G, 0, GH - 1)), int(np.clip((x + HALF_X) // G, 0, GW - 1))


def norm_az(a): return (a + 180.0) % 360.0 - 180.0


def make_deposit(ore, scale, typ, cx, cz, F, Ys, rng, dep_id, target_volume=None, district=""):
    ip, jp = cell_at(cx, cz)
    dip_rng, asp_rng, tf, layout, assoc = TYPES[typ]
    sz = SIZE[scale]
    a = rng.uniform(*sz["a"]); T = rng.uniform(*sz["T"]) * tf
    asp = rng.uniform(*asp_rng)
    if typ == "kimberlite_pipe":
        a *= 0.45; T = rng.uniform(*{"small": (2.0, 3.2), "medium": (3.0, 4.5), "large": (4.0, 6.0), "mega": (5.0, 7.5)}[scale])
    # estilo estrutural: strike alinhado a falha proxima ou ao contorno topografico
    if F["dfault"][ip, jp] < 130 and rng.random() < 0.85:
        az = F["fault_az"][ip, jp] + rng.normal(0, 10)
    else:
        gxv, gzv = F["gx"][ip, jp], F["gy"][ip, jp]
        if math.hypot(gxv, gzv) > 0.12 and rng.random() < 0.8:
            az = math.degrees(math.atan2(gxv, -gzv)) + rng.normal(0, 25)
        else:
            az = rng.uniform(-180, 180)
    az = norm_az(az)
    dip = float(rng.uniform(*dip_rng))
    conc = float(np.clip(sz["conc"] + rng.normal(0, 0.07), 0.3, 0.95))
    irr = float(rng.uniform(0.35, 0.85))
    b = a * asp
    if typ in ("orogenic_quartz_gold_vein", "epithermal_vein", "hydrothermal_quartz_vein", "quartz_reef", "greenstone_lode"):
        a, b = a * 1.25, a * 1.25 * asp            # veios alongados: maior extensao ao longo do strike
    # numero de discos / layout
    nd = {"small": 1 + (rng.random() < 0.3), "medium": int(rng.integers(1, 4)), "large": int(rng.integers(2, 6)), "mega": int(rng.integers(6, 10))}[scale]
    if typ == "kimberlite_pipe": nd = {"small": int(rng.integers(3, 6)), "medium": int(rng.integers(5, 9)), "large": int(rng.integers(8, 13)), "mega": int(rng.integers(12, 17))}[scale]
    if target_volume:  # megas: ajusta escala horizontal para atingir o volume desejado
        for _ in range(3):
            tmp = est_volume([dict(conc=conc, a=a, b=b, T=T)] * 1) * (1 + 0.55 * (nd - 1))
            k = math.sqrt(target_volume / max(tmp, 1.0)); a *= k; b *= k
    # ---- profundidade (classes superficial..extremamente profundo, truncada pela faixa Y do minerio)
    Ysurf = float(Ys[int(np.clip(cz + HALF_Z, 0, H - 1)), int(np.clip(cx + HALF_X, 0, W - 1))])
    lo, hi = ORES[ore]["band"]
    w = np.array(ORES[ore]["depth"]); w = w / w.sum()
    if scale == "mega": w = np.array([0, 0.25, 0.5, 0.25])
    ok = False
    for _ in range(12):
        dc = int(rng.choice(4, p=w)); dd = rng.uniform(*DEPTH_RANGES[dc])
        cy = Ysurf - dd
        cy = float(np.clip(cy, lo, hi))
        cy = max(cy, MIN_Y + 4 + T / 2)
        discs = layout_discs(layout, typ, scale, nd, cx, cy, cz, a, b, T, az, dip, conc, irr, rng)
        top = max(disc_bbox(d)[3] for d in discs); bot = min(disc_bbox(d)[2] for d in discs)
        cap = 1 if (scale == "small" and dc == 0) else 4
        if top > Ysurf - cap - 1:
            sh = top - (Ysurf - cap - 1)
            for d in discs: d["cy"] -= sh
            bot -= sh
        if bot < MIN_Y + 2: continue
        ok = True; break
    if not ok: return None
    for d in discs:
        d["seed"] = int(rng.integers(1, 2 ** 62))
        for k_ in ("cx", "cy", "cz", "a", "b", "T", "az", "dip"): d[k_] = round(float(d[k_]), 3)
        for k_ in ("conc", "irr"): d[k_] = round(float(d[k_]), 4)
    bb = [disc_bbox(d) for d in discs]
    dep = dict(id=dep_id, ore=ore, scale=scale, type=typ, cx=discs[0]["cx"], cz=discs[0]["cz"], cy=discs[0]["cy"],
               y_min=int(min(b_[2] for b_ in bb)), y_max=int(max(b_[3] for b_ in bb)),
               radius_x=float((max(b_[1] for b_ in bb) - min(b_[0] for b_ in bb)) / 2.0),
               radius_z=float((max(b_[5] for b_ in bb) - min(b_[4] for b_ in bb)) / 2.0),
               thickness=discs[0]["T"], azimuth=discs[0]["az"], dip=discs[0]["dip"], concentration=conc, irregularity=irr,
               depth_class=DEPTH_NAMES[dc], min_depth=int(cap), surface_y=Ysurf,
               assoc_ore=assoc[0] if assoc else None, assoc_frac=assoc[1] if assoc else 0.0,
               province=int(F["prov"][ip, jp]), district=district, discs=discs)
    return dep


def layout_discs(layout, typ, scale, nd, cx, cy, cz, a, b, T, az, dip, conc, irr, rng):
    main = dict(cx=cx, cy=cy, cz=cz, a=a, b=b, T=T, az=az, dip=dip, conc=conc, irr=irr)
    discs = [main]
    u, v, n = axes(az, dip)
    for k in range(1, nd):
        if layout == "pipe":
            f = 1.0 - 0.55 * k / max(nd, 2)
            sgn = -1
            dy = -k * T * 1.15
            jit = a * 0.25
            dsc = dict(cx=cx + rng.normal(0, jit), cy=cy + dy + T * 0.5 * (nd - 1) * 0.6, cz=cz + rng.normal(0, jit), a=a * f, b=b * f,
                       T=T * rng.uniform(0.8, 1.05), az=rng.uniform(-180, 180), dip=float(np.clip(dip + rng.normal(0, 6), 0, 35)),
                       conc=conc * rng.uniform(0.85, 1.0), irr=irr)
            discs.append(dsc); continue
        f = rng.uniform(0.35, 0.8)
        if layout == "chain":
            s = (k - 0.5 * (nd - 1)) * a * rng.uniform(0.9, 1.4) * 0.9
            t = rng.uniform(-0.25, 0.25) * b; w_ = rng.uniform(-0.5, 0.5) * T
            f = rng.uniform(0.55, 0.95)
        elif layout == "stack_fan":
            s = rng.uniform(-0.4, 0.4) * a; t = rng.uniform(-0.4, 0.4) * b; w_ = (k - 0.5 * (nd - 1)) * T * 0.9
            f = rng.uniform(0.45, 0.9)
        elif layout == "fan":
            s = rng.uniform(-0.6, 0.6) * a; t = rng.uniform(-0.5, 0.5) * b; w_ = rng.uniform(-0.6, 0.6) * T
        else:  # cluster
            s = rng.uniform(-0.8, 0.8) * a; t = rng.uniform(-0.8, 0.8) * b; w_ = rng.uniform(-0.8, 0.8) * T
        px = cx + s * u[0] + t * v[0] + w_ * n[0]
        py = cy + s * u[1] + t * v[1] + w_ * n[1]
        pz = cz + s * u[2] + t * v[2] + w_ * n[2]
        daz = rng.normal(0, 22 if layout != "fan" else 40)
        discs.append(dict(cx=px, cy=py, cz=pz, a=a * f, b=b * f * rng.uniform(0.8, 1.2), T=T * rng.uniform(0.6, 1.0),
                          az=norm_az(az + daz), dip=float(np.clip(dip + rng.normal(0, 10), 0, 90)),
                          conc=conc * rng.uniform(0.75, 1.0), irr=irr))
    # extensoes / ramificacoes finas nas bordas (apofises)
    ntend = {"small": 0, "medium": int(rng.random() < 0.4), "large": int(rng.integers(2, 5)), "mega": int(rng.integers(4, 8))}[scale]
    if layout == "pipe": ntend = 0
    for _ in range(ntend):
        th = rng.uniform(0, 2 * math.pi); rr = rng.uniform(0.9, 1.35)
        s = math.cos(th) * a * rr; t = math.sin(th) * b * rr
        px = cx + s * u[0] + t * v[0]; py = cy + s * u[1] + t * v[1]; pz = cz + s * u[2] + t * v[2]
        sm = rng.uniform(0.1, 0.22)
        discs.append(dict(cx=px, cy=py, cz=pz, a=max(3.0, a * sm), b=max(2.5, b * sm * rng.uniform(0.6, 1.2)), T=max(1.8, T * 0.4),
                          az=norm_az(az + math.degrees(th) * 0.3 + rng.normal(0, 20)), dip=float(np.clip(dip + rng.normal(0, 12), 0, 90)),
                          conc=conc * 0.8, irr=min(0.9, irr + 0.1)))
    return discs


def pick_type(ore, F, ip, jp, rng):
    land = bool(F["land"][ip, jp]); g = lambda k: float(F[k][ip, jp])
    if ore == "coal":
        return "offshore_coal_seam" if not land else ("coal_seam" if g("sed") > 0.25 or g("humid") > 0.25 else "coal_lens")
    if ore == "iron":
        if not land: return "vms_sulfide_lens"
        if g("shield") > 0.25 or g("craton") > 0.25: return "banded_iron_formation"
        if g("volc") > 0.3 or g("arid") > 0.3: return "hematite_lens"
        return "bog_iron_lens"
    if ore == "copper":
        if not land: return "vms_sulfide_lens"
        if g("volc") > 0.35 or g("O") > 0.35: return "porphyry_stockwork"
        return "oxidized_copper_blanket" if g("arid") > 0.3 else "sediment_hosted_copper"
    if ore == "gold":
        if g("fault") > 0.3: return "orogenic_quartz_gold_vein"
        if g("volc") > 0.3: return "epithermal_vein"
        if g("shield") > 0.25 or g("craton") > 0.25: return "greenstone_lode"
        return "paleoplacer_lens"
    if ore == "redstone": return "skarn_lens" if g("contact") > 0.4 else "hydrothermal_lens"
    if ore == "lapis": return "contact_metamorphic_lens"
    if ore == "diamond": return "kimberlite_pipe"
    if ore == "quartz":
        if g("fault") > 0.3 or g("O") > 0.4: return "hydrothermal_quartz_vein"
        if g("volc") > 0.3: return "volcanic_silica_lens"
        if g("shield") > 0.25: return "pegmatite_lens"
        if not land: return "seafloor_chert_lens"
        return "quartz_reef"


# ----------------------------------------------------------------------------------------------
def main():
    Ys = load_height()
    F, st = load_fields()
    rng_d = np.random.default_rng(MASTER_SEED)
    districts, X, Z = build_districts(F, rng_d)
    json.dump(districts, open(os.path.join(OUT, "districts.json"), "w"), indent=1)
    land_chunks = float(F["land"].sum() * G * G / 256.0)
    deposits = []; dep_id = 0
    D_all = {}
    for ore in ORE_LIST:
        rng = np.random.default_rng(mixseed(MASTER_SEED, ore))
        A = affinity(ore, F)
        Bst = make_boost(ore, districts, X, Z)
        M = regional_modulation(ore, ORES[ore]["num"])
        D = A * Bst * M
        D_all[ore] = D
        pv = (D / D.sum()).ravel(); cdf = np.cumsum(pv); cdf /= cdf[-1]
        total = ORES[ore]["per_chunk"] * land_chunks
        # ---- megas: sitios por maximo de D suavizado (+ bonus estrutural), separados >= 360 blocos
        nm, vol = MEGA[ore]
        S = ndi.gaussian_filter(D, 10); S = S / S.max()
        S[:55, :] = 0; S[-55:, :] = 0; S[:, :55] = 0; S[:, -55:] = 0     # megas nunca encostam na borda do mapa (>= 220 blocos)
        sites = []
        for _ in range(nm):
            i, j = np.unravel_index(np.argmax(S), S.shape)
            sites.append((i, j)); yy, xx = np.ogrid[:GH, :GW]
            S[(yy - i) ** 2 + (xx - j) ** 2 < 90 ** 2] = 0
        for (i, j) in sites:
            cx = float(j * G + 2 - HALF_X); cz = float(i * G + 2 - HALF_Z)
            dep = None
            for t in range(20):
                dep = make_deposit(ore, "mega", MEGA_TYPE[ore], cx, cz, F, Ys, rng, dep_id, target_volume=vol, district="")
                if dep: break
            if dep:
                dep["name"] = f"Mega {ore} #{sum(1 for d in deposits if d['ore']==ore and d['scale']=='mega')+1}"
                deposits.append(dep); dep_id += 1
        # ---- demais classes ate esgotar o orcamento de volume
        spacing = {"large": 70.0}
        grid_large = {}
        for scale in ("large", "medium", "small"):
            budget = total * SHARE[scale]; used = 0.0; guard = 0
            while used < budget and guard < 400000:
                guard += 1
                k = min(int(np.searchsorted(cdf, rng.random())), pv.size - 1)
                i, j = divmod(int(k), GW)
                cx = float(min(j * G + rng.uniform(0, G) - HALF_X, HALF_X - 0.5)); cz = float(min(i * G + rng.uniform(0, G) - HALF_Z, HALF_Z - 0.5))
                if scale == "large":
                    key = (int(cx // 70), int(cz // 70))
                    if any((key[0] + dx, key[1] + dz) in grid_large for dx in (-1, 0, 1) for dz in (-1, 0, 1)): continue
                typ = pick_type(ore, F, i, j, rng)
                dname = ""
                for d in districts:
                    if d["w"].get(ore, 0) > 0 and (cx - d["cx"]) ** 2 + (cz - d["cz"]) ** 2 < d["R"] ** 2: dname = d["name"]; break
                dep = make_deposit(ore, scale, typ, cx, cz, F, Ys, rng, dep_id, district=dname)
                if not dep: continue
                if scale == "large": grid_large[key] = 1
                deposits.append(dep); dep_id += 1
                used += est_volume(dep["discs"])
        print(f"{ore:9s} total={sum(1 for d in deposits if d['ore']==ore):6d}  alvo_blocos={total:,.0f}")
    # volume exato (funcao voxel de referencia) -- uma vez
    print("calculando volumes exatos (referencia voxel)...")
    cc = np.zeros((len(ORE_LIST), H // 16, W // 16), np.int32)       # blocos de minerio por chunk (exato)
    for k, d in enumerate(deposits):
        pts, isa = voxelize_deposit(d)
        d["raw_blocks"] = int(len(pts))
        if len(pts):   # mesma regra do mod: nao rompe a superficie do heightmap (topo = floor(Y)-1, menos min_depth)
            pi_ = np.clip(pts[:, 2] + HALF_Z, 0, H - 1); pj_ = np.clip(pts[:, 0] + HALF_X, 0, W - 1)
            keep = pts[:, 1] <= (np.floor(Ys[pi_, pj_]) - 1 - d["min_depth"])
            pts, isa = pts[keep], isa[keep]
        d["est_blocks"] = int(len(pts))
        d["est_blocks_assoc"] = int(isa.sum())
        if len(pts):
            ci = np.clip((pts[:, 2] >> 4) + H // 32, 0, H // 16 - 1); cj = np.clip((pts[:, 0] >> 4) + W // 32, 0, W // 16 - 1)
            oi = np.where(isa, ORES[d["assoc_ore"]]["num"] if d["assoc_ore"] else ORES[d["ore"]]["num"], ORES[d["ore"]]["num"])
            np.add.at(cc, (oi, ci, cj), 1)
        if k % 4000 == 0: print("  ", k, "/", len(deposits), flush=True)
    np.save(os.path.join(OUT, "chunk_counts.npy"), cc)
    export(deposits, districts, F)


def export(deposits, districts, F):
    prov_names = json.load(open(os.path.join(OUT, "structures.json")))["province_names"]
    meta = dict(
        description="Atlas Geologia - depositos discoidais pre-calculados (fonte unica para mod e imagens)",
        world=dict(map_width=W, map_height=H, blocks_per_pixel=HORIZONTAL_SCALE,
                   pixel_to_world="X = px - 2048 ; Z = py - 1024 (pixel i cobre [i,i+1))", world_to_pixel="px = X + 2048 ; py = Z + 1024",
                   x_range=[-HALF_X, HALF_X - 1], z_range=[-HALF_Z, HALF_Z - 1],
                   height="Y = -21 + value16 / 256", sea_level=SEA_LEVEL, master_seed=MASTER_SEED),
        disc_model="ver deposit_field.py / DepositField.java: u=(cos az,0,sin az); v=(-sin az cos dip,-sin dip,cos az cos dip); n=u x v",
        ores={k: dict(stone=v["stone"], deepslate=v["deep"], color="#%02X%02X%02X" % v["color"], y_band=list(v["band"])) for k, v in ORES.items()},
        provinces=prov_names, count=len(deposits), disc_count=int(sum(len(d["discs"]) for d in deposits)))
    def r(x, n=2): return round(float(x), n)
    out = []
    for d in deposits:
        dd = dict(d)
        for k in ("cx", "cz", "cy", "radius_x", "radius_z", "thickness", "azimuth", "dip", "surface_y"): dd[k] = r(d[k])
        dd["concentration"] = r(d["concentration"], 3); dd["irregularity"] = r(d["irregularity"], 3)
        dd["region"] = prov_names[d["province"]]
        dd["discs"] = [dict(cx=r(x["cx"], 3), cy=r(x["cy"], 3), cz=r(x["cz"], 3), a=r(x["a"], 3), b=r(x["b"], 3), T=r(x["T"], 3),
                            az=r(x["az"], 3), dip=r(x["dip"], 3), conc=r(x["conc"], 4), irr=r(x["irr"], 4), seed=x["seed"]) for x in d["discs"]]
        out.append(dd)
    # arredonda tambem os objetos em memoria usados pelo .bin (mesmos valores do JSON -> consistencia exata)
    json.dump(dict(meta=meta, deposits=out), open(os.path.join(OUT, "deposits.json"), "w"), separators=(",", ":"))
    write_bin(out, os.path.join(OUT, "deposits.bin"))
    # estatisticas
    stats = {}
    for ore in ORE_LIST:
        L = [d for d in out if d["ore"] == ore]
        stats[ore] = {s: dict(n=sum(1 for d in L if d["scale"] == s), blocks=int(sum(d["est_blocks"] for d in L if d["scale"] == s))) for s in SCALES}
        stats[ore]["total_blocks"] = int(sum(d["est_blocks"] for d in L))
    json.dump(stats, open(os.path.join(OUT, "stats.json"), "w"), indent=1)
    print(json.dumps(stats, indent=0)[:1800])


def write_bin(deps, path):
    ore_ids = {o: ORES[o]["num"] for o in ORE_LIST}
    scale_ids = {s: i for i, s in enumerate(SCALES)}
    types = sorted(TYPES); type_ids = {t: i for i, t in enumerate(types)}
    with open(path, "wb") as f:
        f.write(b"ATGD"); f.write(struct.pack(">iii", 1, len(deps), sum(len(d["discs"]) for d in deps)))
        f.write(struct.pack(">i", len(ORE_LIST)))
        for o in ORE_LIST:
            for s in (o, ORES[o]["stone"], ORES[o]["deep"]):
                b = s.encode(); f.write(struct.pack(">H", len(b))); f.write(b)
        f.write(struct.pack(">i", len(types)))
        for t in types:
            b = t.encode(); f.write(struct.pack(">H", len(b))); f.write(b)
        for d in deps:
            ao = ore_ids[d["assoc_ore"]] if d["assoc_ore"] else 255
            f.write(struct.pack(">iBBBBBBd", d["id"], ore_ids[d["ore"]], ao, scale_ids[d["scale"]], type_ids[d["type"]], d["province"],
                                max(0, min(255, d["min_depth"])), float(d["assoc_frac"])))
            f.write(struct.pack(">H", len(d["discs"])))
            for x in d["discs"]:
                f.write(struct.pack(">ddddddddddq", x["cx"], x["cy"], x["cz"], x["a"], x["b"], x["T"], x["az"], x["dip"], x["conc"], x["irr"], x["seed"]))


if __name__ == "__main__":
    main()
