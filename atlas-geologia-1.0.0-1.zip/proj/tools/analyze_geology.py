"""
ETAPA 1-5: interpreta heightmap + mapa de biomas (4096x2048) e constroi o MODELO GEOLOGICO.
Trabalha em grade de 4x4 blocos (1024x512). Saidas:
  out/geology.npz        campos geologicos + provincias
  out/structures.json    cadeias, edificios vulcanicos, calderas/aneis, falhas (lineamentos), contatos
  out/geological_regions.png (4096x2048)
"""
import json, sys
import numpy as np
import cv2
from scipy import ndimage as ndi
from skimage import measure, morphology, filters, feature
from atlas_common import *

G = 4  # blocos por celula
GH, GW = H // G, W // G


def cell_x(j): return (np.asarray(j) + 0.5) * G - HALF_X
def cell_z(i): return (np.asarray(i) + 0.5) * G - HALF_Z


def smoothstep(x, a, b):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def nconv(a, mask, s):
    """gaussiana normalizada (ignora celulas fora da mascara)"""
    num = ndi.gaussian_filter(a * mask, s)
    den = ndi.gaussian_filter(mask.astype(np.float64), s)
    return num / np.maximum(den, 1e-6)


def main():
    Y = load_height()
    idx, names = load_biomes()
    y4 = Y.reshape(GH, G, GW, G).mean((1, 3))
    idx4 = idx[G // 2::G, G // 2::G]                       # bioma no centro da celula
    land = land_mask(idx, names).reshape(GH, G, GW, G).mean((1, 3)) > 0.5
    deep = group_mask(idx4, names, "ocean_deep")
    gm = {g: group_mask(idx4, names, g) for g in GROUPS}

    ys2 = ndi.gaussian_filter(y4, 2)
    ys6 = nconv(y4, land, 6)
    ys40 = nconv(y4, land, 40)
    mu = ndi.gaussian_filter(y4, 8); relief = np.sqrt(np.maximum(ndi.gaussian_filter(y4 ** 2, 8) - mu ** 2, 0))
    gy, gx = np.gradient(ys2)
    slope = np.hypot(gx, gy) / G
    dcoast = ndi.distance_transform_edt(land) * G          # blocos ate o mar (em terra)
    dland = ndi.distance_transform_edt(~land) * G          # blocos ate a terra (no mar)

    # --- orogenia -------------------------------------------------------------------
    O = smoothstep(ys6, 82, 150) * (0.55 + 0.45 * smoothstep(relief, 4, 20)) * land
    O = np.maximum(O, 0.9 * (gm["peaks"] & land) * smoothstep(ys6, 70, 110))
    O = ndi.gaussian_filter(O, 1.0)

    # cadeias montanhosas (componentes conexos)
    lab, n = ndi.label((ys6 > 98) & land)
    ranges = []
    for r in measure.regionprops(lab, intensity_image=y4):
        if r.area < 60: continue
        ci, cj = r.centroid
        ranges.append(dict(id=len(ranges), cx=float(cell_x(cj)), cz=float(cell_z(ci)), area_blocks2=int(r.area * G * G),
                           ymax=float(r.max_intensity), ymean=float(r.mean_intensity),
                           major=float(r.major_axis_length * G), minor=float(r.minor_axis_length * G),
                           angle=float(np.degrees(r.orientation)), cells=r.coords[:, :2].tolist() if r.area < 0 else None))
    ranges.sort(key=lambda d: -d["area_blocks2"])
    for k, d in enumerate(ranges): d["id"] = k

    # --- edificios vulcanicos (picos isolados com drenagem radial) --------------------
    pk = feature.peak_local_max(ndi.gaussian_filter(y4, 5) * land, min_distance=10, threshold_abs=95)
    gy2, gx2 = np.gradient(ndi.gaussian_filter(y4, 2))
    ysp = ndi.gaussian_filter(y4, 5)
    volc = []
    for (r, c) in pk:
        sl = (slice(max(r - 22, 0), r + 23), slice(max(c - 22, 0), c + 23))
        yy, xx = np.mgrid[sl]
        dy, dx = yy - r, xx - c
        rr = np.hypot(dy, dx); m = (rr > 6) & (rr < 20)
        g = np.hypot(gx2[sl], gy2[sl]) + 1e-9
        rad = (gx2[sl] * dx + gy2[sl] * dy) / (g * (rr + 1e-9))
        score = (rad[m] * g[m]).sum() / g[m].sum()
        prom = ysp[r, c] - ysp[sl][m].mean()
        volc.append(dict(cx=float(cell_x(c)), cz=float(cell_z(r)), y=float(ysp[r, c]), prominence=float(prom),
                         radial=float(score)))
    volc = [v for v in volc if v["prominence"] > 22 and v["radial"] < -0.65 and v["y"] > 115]

    # --- calderas / estruturas anulares (contraste anel x centro) --------------------
    base = ndi.gaussian_filter(y4, 1.5)
    rings = []
    best = None
    for rad in range(10, 41, 3):                       # raio em celulas
        k = np.zeros((2 * rad + 5, 2 * rad + 5), np.float32)
        yy, xx = np.mgrid[:k.shape[0], :k.shape[1]]
        rr = np.hypot(yy - rad - 2, xx - rad - 2)
        kr = ((rr > rad - 3) & (rr <= rad + 1)).astype(np.float32); kr /= kr.sum()
        kc = (rr < rad * 0.55).astype(np.float32); kc /= kc.sum()
        con = cv2.filter2D(base.astype(np.float32), -1, kr) - cv2.filter2D(base.astype(np.float32), -1, kc)
        con *= land
        con = np.where(cv2.filter2D(land.astype(np.float32), -1, kr) > 0.95, con, 0)
        con = np.where(cv2.filter2D(base.astype(np.float32), -1, kr) > 85, con, 0)
        rings.append((rad, con))
    stack = np.stack([c for _, c in rings]); rad_arr = np.array([r for r, _ in rings])
    bestc = stack.max(0); bestr = rad_arr[stack.argmax(0)]
    pk2 = feature.peak_local_max(bestc, min_distance=25, threshold_abs=14)
    calderas = [dict(cx=float(cell_x(c)), cz=float(cell_z(r)), radius=float(bestr[r, c] * G), contrast=float(bestc[r, c]))
                for r, c in pk2]
    calderas.sort(key=lambda d: -d["contrast"]); calderas = calderas[:4]

    # --- falhas / lineamentos (vales retilineos longos, em terra e no fundo oceanico) ---
    vall = filters.sato(ys2, sigmas=[2, 3], black_ridges=True)
    thr = np.percentile(vall, 90)
    sk = morphology.skeletonize(vall > thr)
    sk = morphology.remove_small_objects(sk, 15, connectivity=2)
    skimg = (sk * 255).astype(np.uint8)
    lines = cv2.HoughLinesP(skimg, 1, np.pi / 180, threshold=12, minLineLength=18, maxLineGap=4)
    faults = []
    if lines is not None:
        for (x1, y1, x2, y2) in lines[:, 0]:
            L = np.hypot(x2 - x1, y2 - y1) * G
            faults.append(dict(kind='lineament', x1=float(cell_x(x1)), z1=float(cell_z(y1)), x2=float(cell_x(x2)), z2=float(cell_z(y2)), length=float(L)))
    faults.sort(key=lambda d: -d["length"])
    # fusao simples: remove segmentos quase duplicados
    kept = []
    for f in faults:
        mx, mz = (f["x1"] + f["x2"]) / 2, (f["z1"] + f["z2"]) / 2
        if all(np.hypot(mx - (k["x1"] + k["x2"]) / 2, mz - (k["z1"] + k["z2"]) / 2) > 60 for k in kept):
            kept.append(f)
    faults = kept[:110]
    for r_ in ranges[:7]:
        th = np.radians(r_["angle"]); dx_, dz_ = np.sin(th), np.cos(th); hl = r_["major"] / 2
        faults.append(dict(kind='range_axis', x1=r_["cx"] - dx_ * hl, z1=r_["cz"] - dz_ * hl, x2=r_["cx"] + dx_ * hl, z2=r_["cz"] + dz_ * hl, length=r_["major"]))
    fl = np.zeros((GH, GW), np.uint8)
    for f in faults:
        cv2.line(fl, (int((f["x1"] + HALF_X) / G), int((f["z1"] + HALF_Z) / G)),
                 (int((f["x2"] + HALF_X) / G), int((f["z2"] + HALF_Z) / G)), 255, 1)
    dfault = ndi.distance_transform_edt(fl == 0) * G
    # eixo das cadeias tambem e zona estrutural (cinturao de cavalgamento)
    # --- contatos entre formacoes (litologia proxy a partir dos biomas) ---------------
    lit = np.zeros((GH, GW), np.int16)
    code = {"coast": 1, "peaks": 2, "windswept": 2, "badlands": 3, "arid": 4, "humid": 5, "ice": 6, "temperate": 7}
    for g_, c_ in code.items(): lit[gm[g_] & land & (lit == 0)] = c_
    lit[land & (lit == 0)] = 7
    lit[~land] = 0
    # filtro de moda (3 iteracoes) -> formacoes coerentes
    lit_s = lit.copy()
    for _ in range(3):
        votes = np.stack([ndi.uniform_filter((lit_s == c).astype(np.float32), 9) for c in range(8)])
        lit_s = votes.argmax(0).astype(np.int16)
    lit_s[~land] = 0
    edge = (ndi.maximum_filter(lit_s, 3) != ndi.minimum_filter(lit_s, 3)) & land & (lit_s > 1)
    dcontact = ndi.distance_transform_edt(~edge) * G
    front = np.abs(O - 0.3) < 0.12                      # frente orogenica
    dfront = ndi.distance_transform_edt(~front) * G

    # --- bacias, craton, escudo gelado -----------------------------------------------
    basin = smoothstep(ys40 - ys6, 4, 22) * land * (1 - smoothstep(relief, 6, 16))
    inland = smoothstep(dcoast, 50, 220)
    lowrel = 1 - smoothstep(relief, 6, 14)
    volcs = np.zeros((GH, GW)); yy, xx = np.mgrid[:GH, :GW]
    for v in volc:
        volcs = np.maximum(volcs, np.exp(-(((xx * G + 2 - HALF_X - v["cx"]) ** 2 + (yy * G + 2 - HALF_Z - v["cz"]) ** 2) / (2 * 55.0 ** 2))))
    for c in calderas:
        d = np.hypot(xx * G + 2 - HALF_X - c["cx"], yy * G + 2 - HALF_Z - c["cz"])
        volcs = np.maximum(volcs, np.exp(-(d / (c["radius"] * 1.15)) ** 2))
    bad = ndi.gaussian_filter((gm["badlands"] & land).astype(np.float64), 5)
    volcanic = np.clip(np.maximum(volcs, 1.1 * bad), 0, 1) * land
    arid = ndi.gaussian_filter(((gm["arid"] | gm["badlands"]) & land).astype(np.float64), 12)
    humid = ndi.gaussian_filter(((gm["humid"]) & land).astype(np.float64), 12)
    iceland = ndi.gaussian_filter((gm["ice"] & land).astype(np.float64), 12)
    craton = inland * lowrel * (1 - O) * (1 - volcanic * 0.8) * (1 - 0.7 * humid)
    coastal = np.exp(-dcoast / 30.0) * land * (1 - O) * (1 - 0.6 * volcanic)
    sedbasin = np.clip(np.maximum(basin, 0.8 * humid * (1 - O) * np.exp(-dcoast / 500.0)) , 0, 1) * land
    shield = np.clip(iceland * lowrel * (1 - 0.7 * O), 0, 1) * land

    # --- oceano -----------------------------------------------------------------------
    shelf = (~land) & (~deep)
    rift = np.exp(-dfault / 70.0) * (~land)
    ridgeo = ndi.gaussian_filter(np.maximum(0, ys2 - ndi.gaussian_filter(y4, 14)) * (~land), 2)
    mor = np.clip(rift * 0.8 + smoothstep(ridgeo, 1.5, 6) * 0.8, 0, 1) * deep + 0.35 * rift * shelf
    abyss = deep * (1 - mor)

    prov_names = ["Oceano abissal (pobre)", "Dorsal/rift oceanico hidrotermal", "Plataforma continental",
                  "Nucleo orogenico", "Flanco orogenico / frente de cavalgamento", "Provincia vulcanica / caldera",
                  "Craton (interior estavel)", "Bacia sedimentar", "Planicie costeira / delta",
                  "Planalto arido / oxidado", "Escudo glacial (Fanerozoico antigo)"]
    score = np.stack([
        abyss * 1.0,
        mor * 1.4,
        np.where(shelf, 1.0, 0) * (1 - mor * 0.9),
        O * 1.9,
        0.95 * smoothstep(ys6, 72, 100) * land,
        volcanic * 1.15,
        craton * 1.05,
        sedbasin * 1.0,
        coastal * 0.85,
        arid * (1 - O) * (1 - volcanic) * 0.95,
        shield * 1.0,
    ])
    score[:, ~land & ~deep & ~shelf] = 0
    prov = score.argmax(0).astype(np.int8)
    # em terra nada cai nas classes oceanicas, e vice-versa
    land_default = np.where((lowrel > 0.5) & (dcoast > 60), 6, 8)
    prov = np.where(land & (prov < 3), land_default, prov)
    prov = np.where(~land & (prov >= 3), np.where(deep, 0, 2), prov)

    np.savez_compressed(os.path.join(OUT, "geology.npz"),
                        y4=y4.astype(np.float32), land=land, deep=deep, relief=relief.astype(np.float32),
                        slope=slope.astype(np.float32), dcoast=dcoast.astype(np.float32), dland=dland.astype(np.float32),
                        O=O.astype(np.float32), volcanic=volcanic.astype(np.float32), craton=craton.astype(np.float32),
                        sedbasin=sedbasin.astype(np.float32), coastal=coastal.astype(np.float32),
                        arid=arid.astype(np.float32), humid=humid.astype(np.float32), shield=shield.astype(np.float32),
                        dfault=dfault.astype(np.float32), dcontact=dcontact.astype(np.float32), dfront=dfront.astype(np.float32),
                        mor=mor.astype(np.float32), abyss=abyss.astype(np.float32), shelf=shelf, prov=prov,
                        lit=lit_s.astype(np.int8), ys6=ys6.astype(np.float32), gx=gx.astype(np.float32), gy=gy.astype(np.float32))
    json.dump(dict(ranges=ranges, volcanic_edifices=volc, calderas=calderas, faults=faults, province_names=prov_names,
                   grid_block=G, note="coordenadas em blocos (X,Z) conforme conversao px-2048 / py-1024"),
              open(os.path.join(OUT, "structures.json"), "w"), indent=1)

    # --- imagem de regioes geologicas ---------------------------------------------------
    pal = np.array([(26, 35, 80), (190, 50, 110), (60, 110, 170), (120, 85, 60), (170, 130, 80), (215, 70, 40),
                    (120, 160, 90), (70, 150, 120), (210, 200, 130), (205, 140, 60), (170, 200, 220)], np.uint8)
    rgb4 = pal[prov]
    img = cv2.resize(rgb4, (W, H), interpolation=cv2.INTER_NEAREST)
    # sombreado do relevo p/ legibilidade
    sh = cv2.resize(((ys2 - ys2.min()) / (ys2.max() - ys2.min())).astype(np.float32), (W, H), interpolation=cv2.INTER_LINEAR)
    img = np.clip(img.astype(np.float32) * (0.75 + 0.5 * sh[..., None]), 0, 255).astype(np.uint8)
    for f in faults:
        cv2.line(img, (int(f["x1"] + HALF_X), int(f["z1"] + HALF_Z)), (int(f["x2"] + HALF_X), int(f["z2"] + HALF_Z)), (255, 255, 255), 1, cv2.LINE_AA)
    for v in volc:
        cv2.circle(img, (int(v["cx"] + HALF_X), int(v["cz"] + HALF_Z)), 14, (255, 40, 0), 3, cv2.LINE_AA)
    for c in calderas:
        cv2.circle(img, (int(c["cx"] + HALF_X), int(c["cz"] + HALF_Z)), int(c["radius"]), (255, 255, 0), 3, cv2.LINE_AA)
    from PIL import Image, ImageDraw, ImageFont
    pim = Image.fromarray(img); d = ImageDraw.Draw(pim)
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 34)
    f2 = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 26)
    d.rectangle([20, 20, 760, 70 + 40 * len(prov_names)], fill=(0, 0, 0, 255))
    d.text((34, 26), "Regioes geologicas (modelo derivado dos mapas 4096x2048)", font=f2, fill=(255, 255, 255))
    for k, nm in enumerate(prov_names):
        d.rectangle([34, 70 + 40 * k, 74, 100 + 40 * k], fill=tuple(int(v) for v in pal[k]))
        d.text((88, 68 + 40 * k), nm, font=f2, fill=(255, 255, 255))
    pim.save(os.path.join(OUT, "geological_regions.png"))
    print("cadeias:", len(ranges), "vulcoes:", len(volc), "calderas:", len(calderas), "falhas:", len(faults))
    for k, nm in enumerate(prov_names):
        print(f"  {nm:48s} {100 * (prov == k).mean():5.1f}%")
    for c in calderas: print("  caldera", c)
    for r in ranges[:10]: print("  range", {k: round(v, 1) if isinstance(v, float) else v for k, v in r.items() if k != 'cells'})


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    main()
