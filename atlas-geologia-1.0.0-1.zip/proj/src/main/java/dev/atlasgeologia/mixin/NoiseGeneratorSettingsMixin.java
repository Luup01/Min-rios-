package dev.atlasgeologia.mixin;

import dev.atlasgeologia.AtlasConfig;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Desliga os "ore veins" do noise vanilla (blocos raw_iron/raw_copper e veios gigantes) - a geologia vem do Atlas. */
@Mixin(NoiseGeneratorSettings.class)
public abstract class NoiseGeneratorSettingsMixin {
    @Inject(method = "oreVeinsEnabled", at = @At("HEAD"), cancellable = true, require = 0)
    private void atlasgeologia$noVanillaOreVeins(CallbackInfoReturnable<Boolean> cir) {
        if (AtlasConfig.get().disable_vanilla_ore_veins) cir.setReturnValue(false);
    }
}
