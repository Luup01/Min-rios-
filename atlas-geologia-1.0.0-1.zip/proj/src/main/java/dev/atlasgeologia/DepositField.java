package dev.atlasgeologia;

/**
 * Funcao voxel dos discos minerais - ESPELHO EXATO de tools/deposit_field.py.
 * Somente + - * / sqrt floor e hash splitmix64 (sem pow/exp), trigonometria via StrictMath: resultado
 * reprodutivel bit-a-bit entre plataformas. Nenhum estado, nenhum Random: o bloco depende apenas
 * dos parametros do deposito e das coordenadas (X,Y,Z) => independe da ordem de geracao dos chunks.
 */
public final class DepositField {
    public static final double EDGE_AMP = 0.30;
    public static final double EDGE_REACH = 1.0 + EDGE_AMP + 0.01;
    public static final double THICK_AMP = 0.35;
    private static final long C1 = 0xBF58476D1CE4E5B9L, C2 = 0x94D049BB133111EBL;
    private static final long KX = 0x9E3779B97F4A7C15L, KY = 0xC2B2AE3D27D4EB4FL, KZ = 0x165667B19E3779F9L;
    private static final double INV53 = 1.0 / 9007199254740992.0;

    private DepositField() {}

    private static long mix(long z) {
        z = (z ^ (z >>> 30)) * C1;
        z = (z ^ (z >>> 27)) * C2;
        return z ^ (z >>> 31);
    }

    public static double hash01(long seed, int x, int y, int z) {
        long h = seed;
        h = mix(h ^ ((long) x * KX));
        h = mix(h ^ ((long) y * KY));
        h = mix(h ^ ((long) z * KZ));
        return (double) (h >>> 11) * INV53;
    }

    /** ruido de valor 2D suave em [-1,1] */
    static double vnoise2(long seed, double a, double b) {
        double fa0 = Math.floor(a), fb0 = Math.floor(b);
        double fa = a - fa0, fb = b - fb0;
        double sa = fa * fa * (3.0 - 2.0 * fa), sb = fb * fb * (3.0 - 2.0 * fb);
        int ia = (int) fa0, ib = (int) fb0;
        long s2 = seed ^ 0x5DEECE66DL;
        double v00 = hash01(s2, ia, 91, ib), v10 = hash01(s2, ia + 1, 91, ib);
        double v01 = hash01(s2, ia, 91, ib + 1), v11 = hash01(s2, ia + 1, 91, ib + 1);
        double top = v00 * (1.0 - sa) + v10 * sa;
        double bot = v01 * (1.0 - sa) + v11 * sa;
        return 2.0 * (top * (1.0 - sb) + bot * sb) - 1.0;
    }

    /** probabilidade do bloco (x,y,z) pertencer ao disco (0 fora). */
    public static double prob(Disc d, int x, int y, int z) {
        double px = x + 0.5 - d.cx, py = y + 0.5 - d.cy, pz = z + 0.5 - d.cz;
        double ww = px * d.nx + py * d.ny + pz * d.nz;
        double aw = Math.abs(ww);
        if (aw > d.hmaxT) return 0.0;                       // rejeicao rapida (equivalente: hT <= hmaxT)
        double uu = px * d.ux + py * d.uy + pz * d.uz;
        double vv = px * d.vx + py * d.vy + pz * d.vz;
        double ua = uu / d.a, vb = vv / d.b;
        double rn = Math.sqrt(ua * ua + vb * vb);
        if (!(rn < EDGE_REACH)) return 0.0;
        double r = rn + d.irr * EDGE_AMP * vnoise2(d.seed, uu / d.ls, vv / d.ls);
        double s = 1.0 - r * r;
        if (!(s > 0.0)) return 0.0;
        double sq = Math.sqrt(s);
        double hT = 0.5 * d.T * (sq * Math.sqrt(sq)) * (1.0 + d.irr * THICK_AMP * vnoise2(d.seed ^ 0x2545F491L, uu / d.ls2 + 17.3, vv / d.ls2 - 5.1));
        if (!(hT > 0.0) || !(aw <= hT)) return 0.0;
        double q = aw / hT;
        double f = sq * (1.0 - 0.45 * q * q);
        return d.conc * (0.25 + 0.75 * f);
    }

    public interface HitConsumer { void hit(int x, int y, int z, int ore); }

    /**
     * Percorre todos os blocos de minerio do deposito dentro do retangulo (inclusivo) e do intervalo Y.
     * Usado pelo gerador de chunks E pelo teste de validacao contra a referencia python.
     */
    public static void forEachHit(Deposit dep, int xa, int xb, int za, int zb, int ya, int yb, double scale, HitConsumer out) {
        long assocSeed = dep.discs[0].seed ^ 0x7A7A7A7AL;
        for (Disc d : dep.discs) {
            int x0 = Math.max(d.x0, xa), x1 = Math.min(d.x1, xb);
            int z0 = Math.max(d.z0, za), z1 = Math.min(d.z1, zb);
            int y0 = Math.max(d.y0, ya), y1 = Math.min(d.y1, yb);
            if (x0 > x1 || z0 > z1 || y0 > y1) continue;
            for (int x = x0; x <= x1; x++)
                for (int z = z0; z <= z1; z++)
                    for (int y = y0; y <= y1; y++) {
                        double p = prob(d, x, y, z);
                        if (p <= 0.0) continue;
                        if (hash01(d.seed, x, y, z) >= p * scale) continue;
                        int ore = dep.ore;
                        if (dep.assocFrac > 0.0 && dep.assocOre >= 0 && hash01(assocSeed, x, y, z) < dep.assocFrac) ore = dep.assocOre;
                        out.hit(x, y, z, ore);
                    }
        }
    }
}
