"""
ETAPA 8: gera as imagens DIRETAMENTE de out/deposits.json (+ chunk_counts.npy calculado pela mesma funcao voxel).
Nenhuma distribuicao e inventada aqui: cada poligono e a pegada (r=1) de um disco real do deposito.
  mineral_distribution.png  mineral_density.png  mega_deposits.png  quartz_distribution.png
"""
import json, math
import numpy as np
import cv2
from scipy import ndimage as ndi
from PIL import Image, ImageDraw, ImageFont
from atlas_common import *
from deposit_field import axes

FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
ORE_NAMES = {"coal": "Carvao", "iron": "Ferro", "copper": "Cobre", "gold": "Ouro", "redstone": "Redstone", "lapis": "Lapis-lazuli",
             "diamond": "Diamante", "quartz": "Quartzo"}
SCALE_NAMES = {"small": "Pequeno", "medium": "Medio", "large": "Grande", "mega": "MEGA"}


def hexrgb(h): return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))
def tcol(c): return c if sum(c) > 250 else (175, 175, 190)      # texto legivel sobre fundo escuro (carvao)


def base_map(dim=1.0):
    Y = load_height(); idx, names = load_biomes()
    land = land_mask(idx, names)
    gy, gx = np.gradient(cv2.GaussianBlur(Y.astype(np.float32), (0, 0), 1.2))
    shade = np.clip(0.5 + (-gx - gy) * 0.35, 0.2, 1.0)
    img = np.zeros((H, W, 3), np.float32)
    depth = np.clip((SEA_LEVEL - Y) / 40.0, 0, 1)[..., None]
    ocean = np.array([78, 108, 140], np.float32) * (1 - depth) + np.array([24, 38, 74], np.float32) * depth
    lc = np.clip((Y - 63) / 130.0, 0, 1)[..., None]
    landc = np.array([112, 118, 104], np.float32) * (1 - lc) + np.array([190, 186, 176], np.float32) * lc
    img = np.where(land[..., None], landc * (0.95 + 0.6 * shade[..., None] * 0.6), ocean)
    return np.clip(img * dim, 0, 255).astype(np.uint8)


def footprint(d, k=48, scale=1.0):
    u, v, n = axes(d["az"], d["dip"])
    th = np.linspace(0, 2 * math.pi, k, endpoint=False)
    s = np.cos(th) * d["a"] * scale; t = np.sin(th) * d["b"] * scale
    x = d["cx"] + s * u[0] + t * v[0]; z = d["cz"] + s * u[2] + t * v[2]
    return np.stack([(x + HALF_X), (z + HALF_Z)], 1)


def fill(img, pts, color, outline=None):
    p = np.round(pts * 16).astype(np.int32)
    cv2.fillPoly(img, [p], color, lineType=cv2.LINE_AA, shift=4)
    if outline: cv2.polylines(img, [p], True, outline, 1, cv2.LINE_AA, shift=4)


def load():
    D = json.load(open(os.path.join(OUT, "deposits.json")))
    return D["meta"], D["deposits"]


def legend(pim, meta, deps, title, ores=None, x0=24, y0=24, extra=None):
    d = ImageDraw.Draw(pim)
    fb = ImageFont.truetype(FB, 30); fr = ImageFont.truetype(FR, 24); fs = ImageFont.truetype(FR, 20)
    ores = ores or list(meta["ores"])
    h = 120 + 38 * len(ores) + 230
    d.rectangle([x0, y0, x0 + 700, y0 + h], fill=(10, 12, 20), outline=(220, 220, 220), width=2)
    d.text((x0 + 16, y0 + 10), title, font=fb, fill=(255, 255, 255))
    d.text((x0 + 16, y0 + 52), "Fonte: deposits.json (mesmos dados do mod) | 1 px = 1 bloco | X=px-2048, Z=py-1024", font=fs, fill=(200, 200, 200))
    y = y0 + 90
    for o in ores:
        c = hexrgb(meta["ores"][o]["color"])
        L = [q for q in deps if q["ore"] == o]
        d.ellipse([x0 + 16, y + 4, x0 + 40, y + 28], fill=c, outline=(255, 255, 255))
        d.text((x0 + 54, y), f"{ORE_NAMES[o]:13s}", font=fr, fill=(255, 255, 255))
        d.text((x0 + 230, y + 3), f"{len(L):5d} dep. | {sum(q['est_blocks'] for q in L):>9,d} blocos".replace(",", "."), font=fs, fill=(220, 220, 220))
        y += 38
    y += 8
    d.text((x0 + 16, y), "Tamanho (semi-eixo a, escala real): Pequeno 3-7 | Medio 8-17", font=fs, fill=(230, 230, 230)); y += 26
    d.text((x0 + 16, y), "Grande 24-46 | MEGA 60-105 blocos (+ ramificacoes)", font=fs, fill=(230, 230, 230)); y += 26
    d.text((x0 + 16, y), "Brilho do disco = concentracao do deposito (0.3 a 0.95)", font=fs, fill=(230, 230, 230)); y += 26
    d.text((x0 + 16, y), "Anel branco + rotulo = MEGA deposito (identificado)", font=fs, fill=(230, 230, 230)); y += 26
    if extra:
        for e in extra: d.text((x0 + 16, y), e, font=fs, fill=(230, 230, 230)); y += 26
    return pim


def megas_of(deps): return [q for q in deps if q["scale"] == "mega"]


def label_megas(pim, meta, deps, big=False, avoid_rects=()):
    """rotulos dos megas posicionados SEM cobrir o centro de nenhum disco de nenhum mega nem retangulos reservados"""
    d = ImageDraw.Draw(pim); f = ImageFont.truetype(FB, 24 if big else 20)
    M = megas_of(deps)
    pts = [(dsc["cx"] + HALF_X, dsc["cz"] + HALF_Z) for m in M for dsc in m["discs"]]
    placed = list(avoid_rects)
    cnt = {}
    for q in M:
        cnt[q["ore"]] = cnt.get(q["ore"], 0) + 1
        px, py = q["cx"] + HALF_X, q["cz"] + HALF_Z
        r = max(q["radius_x"], q["radius_z"]) + 10
        d.ellipse([px - r, py - r, px + r, py + r], outline=(255, 255, 255), width=3)
        txt = f"M-{ORE_NAMES[q['ore']]} {cnt[q['ore']]} ({q['est_blocks'] // 1000}k)"
        tw = d.textlength(txt, font=f); th = 30
        cands = []
        for dy in (-r - 34, r + 6, -r - 70, r + 42):
            for dx in (0, -tw * 0.6, tw * 0.6):
                cands.append((px + dx - tw / 2, py + dy))
        for dx in (r + 8, -r - 8 - tw):
            cands.append((px + dx, py - th / 2))
        best = None
        for (lx, ly) in cands:
            lx = min(max(lx, 6), W - tw - 14); ly = min(max(ly, 6), H - th - 6)
            box = (lx - 4, ly, lx + tw + 4, ly + th)
            if any(box[0] - 2 <= x <= box[2] + 2 and box[1] - 2 <= y <= box[3] + 2 for x, y in pts): continue
            if any(not (box[2] < p[0] or box[0] > p[2] or box[3] < p[1] or box[1] > p[3]) for p in placed): continue
            best = box; break
        if best is None: continue
        placed.append(best)
        d.rectangle(best, fill=(0, 0, 0))
        d.text((best[0] + 4, best[1]), txt, font=f, fill=tcol(hexrgb(meta["ores"][q["ore"]]["color"])))
    return pim


def render_distribution(meta, deps):
    img = base_map(1.0)
    cc = np.load(os.path.join(OUT, "chunk_counts.npy")).astype(np.float64)
    for o, info in meta["ores"].items():                      # halo de concentracao regional (dados reais por chunk)
        k = list(meta["ores"]).index(o)
        a = ndi.gaussian_filter(cc[k], 2.0); a = np.clip(np.log1p(a) / max(np.log1p(np.percentile(a[a > 0], 99.5)), 1e-6), 0, 1) ** 1.6
        big = cv2.resize(a.astype(np.float32), (W, H), interpolation=cv2.INTER_CUBIC)
        img = np.clip(img.astype(np.float32) + big[..., None] * np.array(hexrgb(info["color"]), np.float32) * 0.17, 0, 255).astype(np.uint8)
    order = {"mega": 3, "large": 2, "medium": 1, "small": 0}
    for q in sorted(deps, key=lambda q: order[q["scale"]]):
        c = np.array(hexrgb(meta["ores"][q["ore"]]["color"]), np.float32)
        k = 0.62 + 0.38 * (q["concentration"] - 0.3) / 0.65
        col = tuple(int(x) for x in np.clip(c * k, 0, 255))
        for dsc in q["discs"]:
            fill(img, footprint(dsc), col, (215, 215, 215) if q["ore"] == "coal" else None)
    pim = Image.fromarray(img)
    pim = label_megas(pim, meta, deps)
    pim = legend(pim, meta, deps, "Distribuicao mineral - Atlas Geologia")
    pim.save(os.path.join(OUT, "mineral_distribution.png"), optimize=True)


def render_density(meta, deps):
    cc = np.load(os.path.join(OUT, "chunk_counts.npy")).astype(np.float64)
    img = np.zeros((H, W, 3), np.float32) + base_map(0.28).astype(np.float32)
    for o, info in meta["ores"].items():
        k = list(meta["ores"]).index(o)
        a = ndi.gaussian_filter(cc[k], 1.2)
        a = np.log1p(a) / max(np.log1p(np.percentile(a[a > 0], 99.5)), 1e-6)
        a = np.clip(a, 0, 1) ** 1.2
        big = cv2.resize(a.astype(np.float32), (W, H), interpolation=cv2.INTER_CUBIC)
        img += big[..., None] * np.array(hexrgb(info["color"]), np.float32) * 0.9
    img = np.clip(img, 0, 255).astype(np.uint8)
    pim = Image.fromarray(img)
    pim = legend(pim, meta, deps, "Densidade mineral regional (blocos/chunk, escala log)",
                 extra=["Cor = minerio dominante; brilho = blocos por chunk", "(contagem exata da funcao voxel por chunk 16x16)"])
    pim.save(os.path.join(OUT, "mineral_density.png"), optimize=True)


def render_megas(meta, deps):
    img = base_map(0.55)
    for q in sorted(deps, key=lambda q: q["scale"] == "mega"):
        if q["scale"] != "mega": continue
        col = hexrgb(meta["ores"][q["ore"]]["color"])
        for dsc in q["discs"]: fill(img, footprint(dsc), col, (255, 255, 255) if min(dsc["a"], dsc["b"]) >= 9 else None)
    pim = Image.fromarray(img)
    M = megas_of(deps); M.sort(key=lambda q: (q["ore"], -q["est_blocks"]))
    fb = ImageFont.truetype(FB, 22); fr = ImageFont.truetype(FR, 18)
    half = (len(M) + 1) // 2
    cw, bh = 1000, 34 + 26 * half + 14
    bw = cw * 2
    # varre posicoes e escolhe a de menor sobreposicao com discos/aneis dos megas
    best = None
    for y0 in range(10, H - bh - 10, 40):
        for x0 in range(10, W - bw - 10, 40):
            n = 0
            for m in M:
                rr = max(m["radius_x"], m["radius_z"]) + 40
                px, py = m["cx"] + HALF_X, m["cz"] + HALF_Z
                if x0 - rr <= px <= x0 + bw + rr and y0 - rr <= py <= y0 + bh + rr: n += 1
            if best is None or n < best[0]: best = (n, x0, y0)
    _, x0, y0 = best
    d = ImageDraw.Draw(pim)
    d.rectangle([x0, y0, x0 + bw, y0 + bh], fill=(10, 12, 20), outline=(255, 255, 255), width=2)
    d.text((x0 + 10, y0 + 4), "MEGA DEPOSITOS (dados reais de deposits.json)  X, Z, faixa Y, discos, blocos de minerio, tipo", font=fb, fill=(255, 255, 255))
    for k, q in enumerate(M):
        cx_ = x0 + 10 + cw * (k // half); y = y0 + 34 + 26 * (k % half)
        d.text((cx_, y), f"{q['name'][5:]:11s} X={q['cx']:6.0f} Z={q['cz']:6.0f} Y{q['y_min']:4d}..{q['y_max']:3d} d={len(q['discs']):2d} {q['est_blocks']:6,d}b {q['type'][:22]}".replace(",", "."),
               font=fr, fill=tcol(hexrgb(meta["ores"][q["ore"]]["color"])))
    pim = label_megas(pim, meta, deps, big=True, avoid_rects=[(x0, y0, x0 + bw, y0 + bh)])
    pim.save(os.path.join(OUT, "mega_deposits.png"), optimize=True)


def render_quartz(meta, deps):
    img = base_map(0.5)
    st = json.load(open(os.path.join(OUT, "structures.json")))
    for f in st["faults"]:
        cv2.line(img, (int(f["x1"] + HALF_X), int(f["z1"] + HALF_Z)), (int(f["x2"] + HALF_X), int(f["z2"] + HALF_Z)), (120, 120, 140), 1, cv2.LINE_AA)
    qc = hexrgb(meta["ores"]["quartz"]["color"])
    for q in deps:
        if q["assoc_ore"] == "quartz" and q["ore"] != "quartz":       # quartzo associado (veios auriferos, porfiros etc.)
            for dsc in q["discs"]: cv2.polylines(img, [np.round(footprint(dsc) * 16).astype(np.int32)], True, (235, 235, 235), 1, cv2.LINE_AA, shift=4)
    for q in sorted([q for q in deps if q["ore"] == "quartz"], key=lambda q: q["scale"] == "mega"):
        for dsc in q["discs"]: fill(img, footprint(dsc), qc, (255, 255, 255) if q["scale"] in ("large", "mega") else None)
    pim = Image.fromarray(img)
    pim = label_megas(pim, meta, [q for q in deps if q["ore"] == "quartz"], big=True)
    n_assoc = sum(1 for q in deps if q["assoc_ore"] == "quartz" and q["ore"] != "quartz")
    pim = legend(pim, meta, deps, "Quartzo - distribuicao propria + associacoes", ores=["quartz"],
                 extra=[f"Violeta = depositos de quartzo ({sum(1 for q in deps if q['ore']=='quartz')})",
                        f"Contorno branco = {n_assoc} depositos de outros minerios com quartzo associado",
                        "Linhas cinza = lineamentos/falhas detectados no heightmap"])
    pim.save(os.path.join(OUT, "quartz_distribution.png"), optimize=True)


if __name__ == "__main__":
    meta, deps = load()
    render_distribution(meta, deps); render_density(meta, deps); render_megas(meta, deps); render_quartz(meta, deps)
    print("ok")
