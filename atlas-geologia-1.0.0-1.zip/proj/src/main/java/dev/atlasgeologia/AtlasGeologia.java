package dev.atlasgeologia;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class AtlasGeologia implements ModInitializer {
    public static final String MOD_ID = "atlas_geologia";
    public static final Logger LOGGER = LoggerFactory.getLogger("AtlasGeologia");

    public static Feature<NoneFeatureConfiguration> DEPOSIT_FEATURE;
    private static volatile DepositDatabase DATABASE;
    private static volatile BlockState[][] ORE_STATES;     // [ore][0=stone,1=deepslate]

    /** minerios vanilla removidos dos biomas (nomes reais de PlacedFeature do 1.20.1) */
    private static final String[] VANILLA_ORES = {
            "ore_coal_upper", "ore_coal_lower", "ore_iron_upper", "ore_iron_middle", "ore_iron_small",
            "ore_gold", "ore_gold_lower", "ore_gold_extra", "ore_redstone", "ore_redstone_lower",
            "ore_diamond", "ore_diamond_large", "ore_diamond_buried", "ore_lapis", "ore_lapis_buried",
            "ore_copper", "ore_copper_large"};

    @Override
    public void onInitialize() {
        AtlasConfig cfg = AtlasConfig.get();
        DEPOSIT_FEATURE = registerFeature();

        ResourceKey<PlacedFeature> placed = ResourceKey.create(Registries.PLACED_FEATURE, new ResourceLocation(MOD_ID, "mineral_deposits"));
        // 1) remove os minerios vanilla (fase REMOVALS)
        if (cfg.remove_vanilla_ores) {
            BiomeModifications.create(new ResourceLocation(MOD_ID, "remove_vanilla_ores"))
                    .add(ModificationPhase.REMOVALS, BiomeSelectors.all(), ctx -> {
                        for (String n : VANILLA_ORES) {
                            ctx.getGenerationSettings().removeFeature(GenerationStep.Decoration.UNDERGROUND_ORES,
                                    ResourceKey.create(Registries.PLACED_FEATURE, new ResourceLocation("minecraft", n)));
                        }
                    });
        }
        // 2) adiciona o gerador de depositos (roda uma vez por chunk; filtra dimensao internamente)
        BiomeModifications.addFeature(BiomeSelectors.all(), GenerationStep.Decoration.UNDERGROUND_ORES, placed);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("atlasgeo").requires(s -> s.hasPermission(2))
                        .executes(c -> {
                            DepositDatabase db = database();
                            c.getSource().sendSuccess(() -> Component.literal(db == null ? "AtlasGeologia: banco nao carregado"
                                    : "AtlasGeologia: " + db.deposits.length + " depositos / " + db.discCount + " discos"), false);
                            return Command.SINGLE_SUCCESS;
                        })
                        .then(Commands.literal("nearby").executes(c -> {
                            DepositDatabase db = database();
                            Vec3 p = c.getSource().getPosition();
                            int x = (int) Math.floor(p.x), z = (int) Math.floor(p.z);
                            List<Deposit> L = db.query(x - 128, z - 128, x + 128, z + 128);
                            c.getSource().sendSuccess(() -> Component.literal("Depositos num raio de ~128 blocos: " + L.size()), false);
                            int shown = 0;
                            for (Deposit d : L) {
                                if (shown++ >= 12) break;
                                Disc m = d.discs[0];
                                String msg = String.format("#%d %s [%s] centro=(%.0f, %.0f, %.0f) Y %d..%d discos=%d", d.id, db.oreKeys[d.ore],
                                        db.typeNames[d.type], m.cx, m.cy, m.cz, d.minY, d.maxY, d.discs.length);
                                c.getSource().sendSuccess(() -> Component.literal(msg), false);
                            }
                            return Command.SINGLE_SUCCESS;
                        }))));
    }

    private static Feature<NoneFeatureConfiguration> registerFeature() {
        Feature<NoneFeatureConfiguration> f = new DepositFeature(NoneFeatureConfiguration.CODEC);
        return net.minecraft.core.Registry.register(BuiltInRegistries.FEATURE, new ResourceLocation(MOD_ID, "mineral_deposits"), f);
    }

    /** carrega (uma unica vez, thread-safe) o banco de depositos: override em config/ ou recurso embutido no jar. */
    public static DepositDatabase database() {
        DepositDatabase db = DATABASE;
        if (db != null) return db;
        synchronized (AtlasGeologia.class) {
            if (DATABASE != null) return DATABASE;
            try {
                AtlasConfig cfg = AtlasConfig.get();
                Path override = FabricLoader.getInstance().getConfigDir().resolve(cfg.deposits_override);
                InputStream in;
                if (Files.exists(override)) { in = Files.newInputStream(override); LOGGER.info("[AtlasGeologia] usando {}", override); }
                else in = AtlasGeologia.class.getResourceAsStream("/data/" + MOD_ID + "/deposits.bin");
                if (in == null) throw new IOException("deposits.bin nao encontrado");
                long t0 = System.nanoTime();
                try (InputStream i2 = in) { DATABASE = DepositDatabase.load(i2); }
                BlockState[][] st = new BlockState[DATABASE.oreKeys.length][2];
                for (int i = 0; i < st.length; i++) {
                    st[i][0] = blockOf(DATABASE.oreStoneIds[i]); st[i][1] = blockOf(DATABASE.oreDeepIds[i]);
                }
                ORE_STATES = st;
                LOGGER.info("[AtlasGeologia] {} depositos / {} discos carregados em {} ms", DATABASE.deposits.length, DATABASE.discCount,
                        (System.nanoTime() - t0) / 1_000_000);
            } catch (IOException e) {
                LOGGER.error("[AtlasGeologia] falha ao carregar deposits.bin - geracao desativada", e);
                return null;
            }
            return DATABASE;
        }
    }

    private static BlockState blockOf(String id) {
        Block b = BuiltInRegistries.BLOCK.get(new ResourceLocation(id));
        if (b == Blocks.AIR) throw new IllegalStateException("bloco inexistente: " + id);
        return b.defaultBlockState();
    }

    public static BlockState oreState(int ore, boolean deepslate) { return ORE_STATES[ore][deepslate ? 1 : 0]; }
}
