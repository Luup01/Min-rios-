# Atlas Geologia (Fabric 1.20.1)

Geração mineral **pré-determinada** e geologicamente coerente para o planeta 4096×2048 do **NovoAtlas**.
Substitui os minérios vanilla por **depósitos discoidais 3D** (estilo Vintage Story). **Não altera** terreno, biomas, relevo, oceanos nem rios: só escreve minério dentro de rocha hospedeira (`stone_ore_replaceables` / `deepslate_ore_replaceables`).

## Conversão pixel ⇄ mundo (validada)
`planeta.json` não define `horizontal_scale` → NovoAtlas usa 1,0: **1 pixel = 1 bloco**, mapa centrado em (0,0), topo = Norte (−Z).

    X = px − 2048      Z = py − 1024        (px = X + 2048,  py = Z + 1024)
    Y = −21 + valor16bit / 256               (oceano ≤ 63 e praias 63–65,7 confirmam a fórmula)

Se algum dia usar `horizontal_scale` ≠ 1, altere `HORIZONTAL_SCALE` em `tools/atlas_common.py` e rode o pipeline.

## Compilar e instalar
Requisitos: JDK 17, Gradle 8.5 (ou IntelliJ).

    gradle wrapper --gradle-version 8.5      # uma vez
    ./gradlew build                          # jar em build/libs/atlas-geologia-1.0.0.jar


### Compilar na nuvem (GitHub Actions)
O projeto já traz `.github/workflows/build.yml`. Suba o **conteúdo da pasta `proj`** (com `build.gradle` na raiz do repositório) para um repositório no GitHub; a aba **Actions** compila sozinha a cada push. Quando terminar, abra a execução e baixe o artefato **atlas-geologia-jar**. Para rodar manualmente: Actions → *Build Atlas Geologia* → *Run workflow*. Ao criar uma tag `v1.0.0`, o jar também é publicado em *Releases*.

Instale em `mods/` junto com **Fabric API 0.92.2+1.20.1** e o **NovoAtlas**. O **Ore Veins não deve estar instalado** (os dois gerenciam minério). Configuração: `config/atlas_geologia.json` (criado no 1º boot). Para trocar o banco de depósitos sem recompilar: coloque outro `deposits.bin` em `config/atlas_geologia/`.

Comando de depuração (OP): `/atlasgeo` e `/atlasgeo nearby`.

> Em dimensões NovoAtlas cujo `noise_settings` tenha `"ore_veins_enabled": true`, o mod desliga os veios gigantes vanilla via mixin (opcional, `disable_vanilla_ore_veins`). Se preferir, ponha `false` no próprio JSON.

## Como funciona (arquitetura)
1. `tools/analyze_geology.py` lê heightmap + biomas + `planeta.json` e monta o **modelo geológico**: 9 cadeias, 7 edifícios vulcânicos, 4 calderas/estruturas anulares, ~40 lineamentos/falhas, contatos entre formações, frentes orogênicas, crátons, bacias, escudo glacial, plataforma e dorsais oceânicas → 11 províncias (`out/geological_regions.png`).
2. `tools/build_deposits.py` cria afinidades por minério (bioma + relevo + altitude + profundidade + estrutura), 10 **assinaturas regionais** (distritos metalogênicos) e modulação regional (regiões pobres/ricas/excepcionais). Gera os depósitos com seed fixa (`MASTER_SEED`) → `deposits.json` + `deposits.bin` (**fonte única** de mod e imagens).
3. `tools/render_maps.py` desenha as imagens **direto de `deposits.json`** (cada elipse é a pegada real de um disco; densidade = contagem exata por chunk da mesma função voxel).
4. Mod: `DepositDatabase` carrega o `.bin` e indexa em grade 64×64 (nunca varre o planeta). `DepositFeature` roda 1×/chunk e avalia `DepositField` (função pura, hash splitmix64, sem `Random`) **só dentro do chunk atual** → sem costuras, independente da ordem de geração, idêntico em regenerações.

Disco: eixos `u=(cos az,0,sin az)`, `v=(−sin az·cos dip, −sin dip, cos az·cos dip)`, `n=u×v`; raio normalizado perturbado por ruído (borda irregular), espessura em lente `T·(1−r²)^0,75` com variação, probabilidade `conc·(0,25+0,75·núcleo)` (mais denso no centro). Depósitos = vários discos conectados/sobrepostos + apófises finas. Diamante = chaminé kimberlítica (pilha vertical de discos).

## Dados por depósito (`deposits.json`)
`ore, cx, cz, cy, y_min, y_max, radius_x, radius_z, thickness, azimuth, dip, concentration, irregularity, region, type, scale, depth_class, district, assoc_ore/assoc_frac, est_blocks` + lista de `discs` (centro, a, b, T, az, dip, conc, irr, seed).

| Minério | Pequenos | Médios | Grandes | MEGA | Blocos totais |
|---|---|---|---|---|---|
| coal | 6746 | 974 | 38 | 3 | 1.758.980 |
| iron | 4158 | 600 | 21 | 3 | 1.253.473 |
| copper | 2077 | 287 | 12 | 3 | 842.623 |
| gold | 1342 | 181 | 6 | 2 | 223.773 |
| redstone | 1353 | 199 | 11 | 2 | 318.395 |
| lapis | 815 | 125 | 4 | 2 | 164.901 |
| diamond | 479 | 65 | 5 | 2 | 79.109 |
| quartz | 1467 | 220 | 9 | 3 | 379.774 |

Quartzo: distribuição própria (veios hidrotermais em cadeias/falhas, sílica vulcânica, pegmatitos do escudo, recifes de quartzo, chert oceânico) **e** associado a ouro, cobre, ferro, redstone (`assoc_ore`).

## Minérios e IDs
`coal, iron, copper, gold, redstone, lapis, diamond` (+ variantes `deepslate_`) — todos presentes na config padrão do Ore Veins. **Quartzo:** o Overworld não tem minério de quartzo próprio; usa-se `minecraft:nether_quartz_ore` (único ID real). Para outro bloco, edite `ORES["quartz"]` em `build_deposits.py` e rode o pipeline. Esmeralda e minérios de mods não foram incluídos (não existem nos arquivos analisados). Granito/diorito/andesito/tuff vanilla permanecem.

## Reexecutar
    pip install -r requirements.txt
    ATLAS_INPUT_DIR=/pasta/com/mapas tools/run_pipeline.sh
(Mesmos mapas + `MASTER_SEED` ⇒ `deposits.bin` byte a byte idêntico.)
