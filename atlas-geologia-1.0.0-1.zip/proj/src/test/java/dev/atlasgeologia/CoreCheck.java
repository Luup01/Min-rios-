package dev.atlasgeologia;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Teste de validacao SEM Minecraft: carrega deposits.bin com o mesmo carregador do mod e imprime, para cada chunk
 * pedido, todos os blocos de minerio gerados (mesmo codigo DepositField.forEachHit usado pelo DepositFeature,
 * primeiro deposito vence em sobreposicao). Comparado bloco a bloco com a referencia python (tools/validate.py).
 * uso: java -cp <classes> dev.atlasgeologia.CoreCheck deposits.bin chunks.txt out.txt
 */
public class CoreCheck {
    public static void main(String[] a) throws Exception {
        DepositDatabase db;
        try (InputStream in = Files.newInputStream(Paths.get(a[0]))) { db = DepositDatabase.load(in); }
        List<String> lines = Files.readAllLines(Paths.get(a[1]));
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(a[2])))) {
            pw.println("#deposits " + db.deposits.length + " discs " + db.discCount);
            for (String ln : lines) {
                if (ln.isBlank()) continue;
                String[] p = ln.trim().split("\\s+");
                int cx = Integer.parseInt(p[0]), cz = Integer.parseInt(p[1]);
                int x0 = cx * 16, z0 = cz * 16;
                TreeMap<long[], Integer> unused = null;
                HashMap<String, Integer> hits = new HashMap<>();
                List<Deposit> L = db.query(x0, z0, x0 + 15, z0 + 15);
                for (Deposit d : L)
                    DepositField.forEachHit(d, x0, x0 + 15, z0, z0 + 15, -64, 319, 1.0, (x, y, z, ore) -> hits.putIfAbsent(x + " " + y + " " + z, ore));
                pw.println("C " + cx + " " + cz + " " + hits.size());
                ArrayList<String> keys = new ArrayList<>(hits.keySet());
                Collections.sort(keys);
                for (String k : keys) pw.println(k + " " + hits.get(k));
            }
        }
    }
}
