package dev.atlasgeologia;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** config/atlas_geologia.json (criado automaticamente na primeira execucao). */
public final class AtlasConfig {
    /** liga/desliga a geracao dos depositos */
    public boolean enabled = true;
    /** remove as features de minerio vanilla (carvao, ferro, cobre, ouro, redstone, lapis, diamante) de TODOS os biomas */
    public boolean remove_vanilla_ores = true;
    /** desliga os veios de minerio vanilla do noise (raw iron/copper blocks) via mixin em NoiseGeneratorSettings */
    public boolean disable_vanilla_ore_veins = true;
    /** multiplicador global da probabilidade de preenchimento (1.0 = identico a deposits.json / imagens) */
    public double concentration_scale = 1.0;
    /** ids de dimensao onde gerar. Vazio = qualquer dimensao exceto Nether (hasCeiling) e End */
    public List<String> dimensions = new ArrayList<>();
    /** caminho opcional (relativo a config/) de um deposits.bin alternativo, ex.: "atlas_geologia/deposits.bin" */
    public String deposits_override = "atlas_geologia/deposits.bin";
    public boolean debug_log = false;

    private static AtlasConfig INSTANCE;

    public static synchronized AtlasConfig get() {
        if (INSTANCE == null) INSTANCE = load();
        return INSTANCE;
    }

    private static AtlasConfig load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path p = FabricLoader.getInstance().getConfigDir().resolve("atlas_geologia.json");
        try {
            if (Files.exists(p)) {
                AtlasConfig c = gson.fromJson(Files.readString(p), AtlasConfig.class);
                if (c != null) return c;
            }
            AtlasConfig c = new AtlasConfig();
            Files.writeString(p, gson.toJson(c));
            return c;
        } catch (IOException | RuntimeException e) {
            AtlasGeologia.LOGGER.error("[AtlasGeologia] erro lendo config, usando padroes", e);
            return new AtlasConfig();
        }
    }
}
