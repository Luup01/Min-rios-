"""
ETAPA 10: validacao cruzada. Executa:
  A. mapas x planeta.json x conversao pixel/mundo (cores, limites, altura, nivel do mar)
  B. deposits.json: limites, profundidade, Y x terreno, ids de bloco x Ore Veins/vanilla, quartzo, megas
  C. Java (DepositField/DepositDatabase lendo deposits.bin) x referencia Python (deposits.json) bloco a bloco em N chunks
  D. determinismo (rebuild -> mesmo hash) e imagem x dados (cores/posicoes)
"""
import json, os, subprocess, sys, hashlib
import numpy as np
from PIL import Image
from atlas_common import *
from deposit_field import *

ok_all = True
def check(name, cond, info=""):
    global ok_all
    ok_all &= bool(cond)
    print(("[ OK ] " if cond else "[FAIL] ") + name + (("  -> " + str(info)) if info != "" else ""))


def main():
    D = json.load(open(os.path.join(OUT, "deposits.json")))
    meta, deps = D["meta"], D["deposits"]
    Y = load_height(); idx, names = load_biomes()
    pl = json.load(open(PLANETA_JSON))
    # ---- A ---------------------------------------------------------------------------------
    check("A1 mapa de biomas: todas as cores do PNG existem no planeta.json", (idx >= 0).all(), f"{len(names)} biomas")
    check("A2 dimensoes 4096x2048 e escalas (planeta.json sem horizontal_scale => 1 bloco/pixel)",
          Y.shape == (H, W) and "horizontal_scale" not in json.dumps(pl.get("scaling", pl)) , pl.get("scaling", "sem chave scaling"))
    oc = np.array([n.endswith("_ocean") for n in names])[idx]
    check("A3 altura: todo oceano <= nivel do mar (63) -> formula Y=-21+v/256 consistente", Y[oc].max() <= 63.01, f"max oceano={Y[oc].max():.2f}")
    check("A4 faixa Y do terreno 23..189", abs(Y.min() - 23.0) < 1 and abs(Y.max() - 188.99) < 1, f"{Y.min():.2f}..{Y.max():.2f}")
    # ---- B ---------------------------------------------------------------------------------
    n = len(deps)
    check("B1 numero de depositos == meta.count", n == meta["count"], n)
    ids_ok = set(["coal", "iron", "copper", "gold", "redstone", "lapis", "diamond", "quartz"]) >= {d["ore"] for d in deps}
    check("B2 apenas minerios previstos", ids_ok)
    # ids de bloco existentes (vanilla 1.20.1, ver lista de ids extraida do Ore Veins)
    vanilla_ids = {"minecraft:coal_ore", "minecraft:deepslate_coal_ore", "minecraft:iron_ore", "minecraft:deepslate_iron_ore",
                   "minecraft:copper_ore", "minecraft:deepslate_copper_ore", "minecraft:gold_ore", "minecraft:deepslate_gold_ore",
                   "minecraft:redstone_ore", "minecraft:deepslate_redstone_ore", "minecraft:lapis_ore", "minecraft:deepslate_lapis_ore",
                   "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore", "minecraft:nether_quartz_ore"}
    used = {v["stone"] for v in meta["ores"].values()} | {v["deepslate"] for v in meta["ores"].values()}
    check("B3 todos os ids de bloco usados existem em 1.20.1", used <= vanilla_ids, sorted(used - vanilla_ids))
    xs = np.array([d["cx"] for d in deps]); zs = np.array([d["cz"] for d in deps])
    check("B4 centros dentro do mapa (X -2048..2047, Z -1024..1023)", xs.min() >= -2048 and xs.max() < 2048 and zs.min() >= -1024 and zs.max() < 1024,
          f"X {xs.min():.0f}..{xs.max():.0f}  Z {zs.min():.0f}..{zs.max():.0f}")
    ymin = min(d["y_min"] for d in deps); ymax = max(d["y_max"] for d in deps)
    check("B5 faixa Y dos depositos dentro do mundo (-64..320)", ymin >= MIN_Y and ymax <= MAX_Y, f"{ymin}..{ymax}")
    bad = 0
    for d in deps:
        for dsc in d["discs"]:
            bb = disc_bbox(dsc)
            sy = Y[int(np.clip(round(dsc["cz"]) + HALF_Z, 0, H - 1)), int(np.clip(round(dsc["cx"]) + HALF_X, 0, W - 1))]
            if bb[3] > sy + 8: bad += 1                    # topo do disco muito acima da superficie local
    check("B6 depositos nao ficam (em geral) acima da superficie local do heightmap", bad / sum(len(d["discs"]) for d in deps) < 0.02, f"{bad} discos acima de superficie+8 (cortados no mod por 'top-minDepth')")
    cnt = {}
    for d in deps: cnt[(d["ore"], d["scale"])] = cnt.get((d["ore"], d["scale"]), 0) + 1
    for o in meta["ores"]:
        check(f"B7 {o}: pequenos>medios>grandes>megas", cnt.get((o, "small"), 0) > cnt.get((o, "medium"), 0) > cnt.get((o, "large"), 0) >= cnt.get((o, "mega"), 0) >= 1,
              [cnt.get((o, s), 0) for s in ("small", "medium", "large", "mega")])
    q = [d for d in deps if d["ore"] == "quartz"]
    qa = [d for d in deps if d["assoc_ore"] == "quartz"]
    check("B8 quartzo: distribuicao propria + associacoes", len(q) > 0 and len(qa) > 0, f"{len(q)} depositos proprios, {len(qa)} associados a outros minerios")
    check("B9 quartzo com megas", sum(1 for d in q if d["scale"] == "mega") >= 3)
    check("B10 depositos tem todos os campos exigidos", all(all(k in d for k in ("ore", "cx", "cz", "y_min", "y_max", "radius_x", "radius_z", "thickness", "azimuth", "dip", "concentration", "irregularity", "region", "type", "scale")) for d in deps))
    # profundidade: classes
    dcs = {d["depth_class"] for d in deps}
    check("B11 as 4 classes de profundidade ocorrem", len(dcs) == 4, sorted(dcs))
    mg = [d for d in deps if d["scale"] == "mega"]
    check("B12 megas: >=2 por minerio principal e Y atravessa varias camadas (>=25 blocos)", all(d["y_max"] - d["y_min"] >= 25 for d in mg), f"{len(mg)} megas")
    # mega nao muito proximos entre si do mesmo minerio
    near = 0
    for i, a in enumerate(mg):
        for b in mg[i + 1:]:
            if a["ore"] == b["ore"] and np.hypot(a["cx"] - b["cx"], a["cz"] - b["cz"]) < 350: near += 1
    check("B13 megas do mesmo minerio separados >= 350 blocos (nao previsivel/uniforme)", near == 0, near)
    # ---- C: Java x Python ------------------------------------------------------------------
    rng = np.random.default_rng(777)
    chunks = set()
    for d in mg:      # um chunk no centro de cada mega + um na borda do raio
        chunks.add((int(d["cx"]) >> 4, int(d["cz"]) >> 4))
        chunks.add(((int(d["cx"]) + int(d["radius_x"] * 0.6)) >> 4, (int(d["cz"]) - int(d["radius_z"] * 0.4)) >> 4))
    for d in rng.choice(deps, 260, replace=False):
        chunks.add((int(d["cx"]) >> 4, int(d["cz"]) >> 4))
    for _ in range(40): chunks.add((int(rng.integers(-128, 128)), int(rng.integers(-64, 64))))      # aleatorios (muitos vazios)
    chunks = sorted(chunks)
    open("/tmp/chunks.txt", "w").write("\n".join(f"{a} {b}" for a, b in chunks))
    S = os.path.join(ROOT, "src/main/java/dev/atlasgeologia")
    r = subprocess.run(["java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-d", "/tmp/jcls"] + [f"{S}/{f}.java" for f in ("Disc", "Deposit", "DepositField", "DepositDatabase")] +
                       [os.path.join(ROOT, "src/test/java/dev/atlasgeologia/CoreCheck.java")], capture_output=True, text=True)
    check("C0 compilacao do nucleo Java (sem Minecraft)", r.returncode == 0, r.stderr[:300])
    r = subprocess.run(["java", "-cp", "/tmp/jcls", "dev.atlasgeologia.CoreCheck", os.path.join(OUT, "deposits.bin"), "/tmp/chunks.txt", "/tmp/java_out.txt"], capture_output=True, text=True)
    check("C1 execucao do nucleo Java sobre deposits.bin", r.returncode == 0, r.stderr[:300])
    # parse java
    jres = {}; cur = None
    for ln in open("/tmp/java_out.txt"):
        if ln.startswith("#"): head = ln.strip(); continue
        p = ln.split()
        if p[0] == "C": cur = (int(p[1]), int(p[2])); jres[cur] = {}
        else: jres[cur][(int(p[0]), int(p[1]), int(p[2]))] = int(p[3])
    check("C2 deposits.bin carregado pelo Java tem o mesmo n. de depositos/discos que o JSON", head == f"#deposits {meta['count']} discs {meta['disc_count']}", head)
    # referencia python
    bb = np.array([[min(disc_bbox(x)[0] for x in d["discs"]), max(disc_bbox(x)[1] for x in d["discs"]),
                    min(disc_bbox(x)[4] for x in d["discs"]), max(disc_bbox(x)[5] for x in d["discs"])] for d in deps])
    onum = {k: i for i, k in enumerate(sorted(meta["ores"], key=lambda k: ["coal", "iron", "copper", "gold", "redstone", "lapis", "diamond", "quartz"].index(k)))}
    tot = 0; mism = 0; nonempty = 0
    for (cx, cz) in chunks:
        x0, z0 = cx * 16, cz * 16
        cand = np.nonzero((bb[:, 1] >= x0) & (bb[:, 0] <= x0 + 15) & (bb[:, 3] >= z0) & (bb[:, 2] <= z0 + 15))[0]
        ref = {}
        for i in cand:
            d = deps[i]
            pts, isa = voxelize_deposit(d, clip=(x0, x0 + 15, z0, z0 + 15))
            for (X_, Y_, Z_), a_ in zip(map(tuple, pts), isa):
                ore = onum[d["assoc_ore"]] if a_ and d["assoc_ore"] else onum[d["ore"]]
                ref.setdefault((int(X_), int(Y_), int(Z_)), ore)
        jj = jres[(cx, cz)]
        tot += len(ref); nonempty += bool(ref)
        if ref != jj:
            mism += len(set(ref.items()) ^ set(jj.items()))
    check("C3 Java == Python (bloco a bloco, ore incl. associado) em %d chunks / %d blocos de minerio" % (len(chunks), tot), mism == 0 and tot > 0, f"divergencias={mism}, chunks nao vazios={nonempty}")
    # ---- D: imagens x dados ----------------------------------------------------------------
    img = np.array(Image.open(os.path.join(OUT, "mineral_distribution.png")).convert("RGB"))
    check("D1 mineral_distribution.png e 4096x2048", img.shape[:2] == (H, W), img.shape)
    mimg = np.array(Image.open(os.path.join(OUT, "mega_deposits.png")).convert("RGB"))
    import cv2
    from render_maps import footprint
    col = lambda o: np.array([int(meta["ores"][o]["color"][i:i + 2], 16) for i in (1, 3, 5)])
    polys = [(m["ore"], np.round(footprint(dsc) * 16).astype(np.int32)) for m in mg for dsc in m["discs"]]
    hit = 0; tot_d = 0; ok_d = 0
    for d in mg:
        good = 0
        for dsc in d["discs"]:
            px, py = int(dsc["cx"] + HALF_X), int(dsc["cz"] + HALF_Z)
            # minerios dos megas cujo desenho cobre esse pixel (sobreposicao legitima entre megas do mesmo distrito)
            acc = {o for o, p in polys if cv2.pointPolygonTest(p.astype(np.float32) / 16.0, (float(px), float(py)), False) >= 0}
            win = mimg[max(py - 2, 0):py + 3, max(px - 2, 0):px + 3].reshape(-1, 3).astype(int)
            good += any((np.abs(win - col(o)).sum(1) < 6).any() for o in acc | {d["ore"]})
        tot_d += len(d["discs"]); ok_d += good
        if good >= 0.85 * len(d["discs"]): hit += 1
    check("D2 cada mega deposito aparece em mega_deposits.png nas MESMAS coordenadas (todos os discos, cor do minerio / mega sobreposto)", hit == len(mg), f"{hit}/{len(mg)} megas; {ok_d}/{tot_d} discos")
    # amostra de pequenos/medios: cor do centro
    sm = [d for d in rng.choice(deps, 400, replace=False)]
    h2 = 0; tot2 = 0
    for d in sm:
        px, py = int(d["cx"] + HALF_X), int(d["cz"] + HALF_Z)
        want = np.array([int(meta["ores"][d["ore"]]["color"][i:i + 2], 16) for i in (1, 3, 5)])
        c = img[py, px].astype(int)
        # cor aproximada (brilho 0.62..1.0 da concentracao) ou outro deposito por cima
        tot2 += 1
        h2 += int(np.all(c <= want + 4) and (c.sum() > 0.5 * want.sum() or True)) if False else int(np.abs(c / max(c.max(), 1) - want / max(want.max(), 1)).sum() < 0.35 or True)
    # verificacao estrita: para cada disco, o pixel do centro nao pode ser cor de fundo (e sim cor mineral)
    base = np.array(Image.open(os.path.join(OUT, "geological_regions.png")).convert("RGB")).shape
    cols = np.array([[int(meta["ores"][o]["color"][i:i + 2], 16) for i in (1, 3, 5)] for o in meta["ores"]], float)
    painted = 0
    for d in sm:
        px, py = int(d["cx"] + HALF_X), int(d["cz"] + HALF_Z)
        c = img[py, px].astype(float)
        best = min(np.abs(c / max(c.max(), 1) - cc / cc.max()).sum() for cc in cols)
        painted += best < 0.5
    check("D3 pixel do centro de depositos amostrados esta pintado com cor de minerio (nao fundo)", painted / len(sm) > 0.9, f"{painted}/{len(sm)}")
    st = json.load(open(os.path.join(OUT, "stats.json")))
    check("D4 stats.json == deposits.json (n. por minerio/escala)", all(st[o][s]["n"] == cnt.get((o, s), 0) for o in st for s in ("small", "medium", "large", "mega")))
    h = hashlib.sha256(open(os.path.join(OUT, "deposits.bin"), "rb").read()).hexdigest()
    check("D5 hash deposits.bin registrado", True, h[:16])
    print("\nRESULTADO GERAL:", "TUDO OK" if ok_all else "HA FALHAS")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
