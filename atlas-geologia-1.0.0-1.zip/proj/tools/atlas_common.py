"""
Atlas Geologia - modulo comum.

CONVERSAO PIXEL <-> MUNDO (NovoAtlas, 1.20.1)
---------------------------------------------
* planeta.json NAO define horizontal_scale  -> NovoAtlas usa 1.0 (1 pixel = 1 bloco, nearest neighbor).
* O mapa e centrado em (0,0); topo da imagem = Norte (-Z).
* Imagens 4096x2048 (pares) -> nenhum pixel e cortado.
      X = px - 2048        Z = py - 1024        (pixel i cobre o intervalo continuo [i, i+1) )
      px = X + 2048        py = Z + 1024
  Faixa do mundo: X in [-2048, 2047], Z in [-1024, 1023].
* Altura: Y = starting_y + valor16bit * vertical_scale = -21 + v/256   (validado: oceano <= 63, praias 63..65.7)
"""
import json, os
import numpy as np
from PIL import Image

W, H = 4096, 2048
HALF_X, HALF_Z = W // 2, H // 2
HORIZONTAL_SCALE = 1.0          # blocos por pixel (mudar aqui se o dimension json usar horizontal_scale)
STARTING_Y = -21.0
VERTICAL_SCALE = 0.00390625
SEA_LEVEL = 63
MIN_Y, MAX_Y = -64, 320

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
UP = os.environ.get("ATLAS_INPUT_DIR", "/mnt/user-data/uploads")   # pasta com heightmap, biomas, planeta.json e o jar do Ore Veins
HEIGHT_PNG = os.path.join(UP, os.environ.get("ATLAS_HEIGHT", "1000222317.png"))
BIOME_PNG = os.path.join(UP, os.environ.get("ATLAS_BIOMES", "1000223441.png"))
PLANETA_JSON = os.path.join(UP, "planeta.json")
OUT = os.path.join(ROOT, "out")


def px2world_x(px): return (np.asarray(px, dtype=np.float64) - HALF_X) * HORIZONTAL_SCALE
def px2world_z(py): return (np.asarray(py, dtype=np.float64) - HALF_Z) * HORIZONTAL_SCALE
def world2px_x(x): return np.asarray(x, dtype=np.float64) / HORIZONTAL_SCALE + HALF_X
def world2px_z(z): return np.asarray(z, dtype=np.float64) / HORIZONTAL_SCALE + HALF_Z


def load_height():
    v = np.array(Image.open(HEIGHT_PNG)).astype(np.float64)
    return STARTING_Y + v * VERTICAL_SCALE


def load_biomes():
    """retorna (idx[H,W] int16, nomes[list]) usando as cores do planeta.json"""
    d = json.load(open(PLANETA_JSON))
    bl = d["surface_biomes"]["biomes"]
    names = [b["biome"] for b in bl]
    im = np.array(Image.open(BIOME_PNG).convert("RGB")).astype(np.int32)
    code = (im[..., 0] << 16) | (im[..., 1] << 8) | im[..., 2]
    idx = np.full(code.shape, -1, np.int16)
    for i, b in enumerate(bl):
        idx[code == int(b["color"][1:], 16)] = i
    assert (idx >= 0).all(), "pixels sem bioma correspondente no planeta.json"
    return idx, names


OCEAN = lambda n: n.endswith("_ocean")
GROUPS = {
    "ocean_deep": lambda n: n.startswith("minecraft:deep_"),
    "ocean": lambda n: n.endswith("_ocean") and not n.startswith("minecraft:deep_"),
    "coast": lambda n: n.split(":")[1] in ("beach", "snowy_beach", "stony_shore"),
    "peaks": lambda n: n.split(":")[1] in ("stony_peaks", "jagged_peaks", "frozen_peaks", "snowy_slopes", "grove"),
    "windswept": lambda n: n.split(":")[1].startswith("windswept"),
    "badlands": lambda n: n.split(":")[1] in ("badlands", "eroded_badlands", "wooded_badlands"),
    "arid": lambda n: n.split(":")[1] in ("desert", "savanna", "savanna_plateau", "windswept_savanna"),
    "humid": lambda n: n.split(":")[1] in ("swamp", "mangrove_swamp", "jungle", "sparse_jungle", "bamboo_jungle", "dark_forest"),
    "ice": lambda n: n.split(":")[1] in ("snowy_plains", "ice_spikes", "snowy_taiga", "frozen_peaks", "snowy_slopes", "snowy_beach"),
    "temperate": lambda n: n.split(":")[1] in ("plains", "sunflower_plains", "forest", "flower_forest", "birch_forest",
                                               "old_growth_birch_forest", "taiga", "old_growth_pine_taiga",
                                               "old_growth_spruce_taiga", "meadow", "cherry_grove", "mushroom_fields"),
}


def group_mask(idx, names, g):
    f = GROUPS[g]
    lut = np.array([f(n) for n in names] + [False])
    return lut[idx]


def land_mask(idx, names):
    lut = np.array([not OCEAN(n) for n in names])
    return lut[idx]
