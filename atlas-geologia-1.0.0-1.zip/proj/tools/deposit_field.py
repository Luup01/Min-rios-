"""
IMPLEMENTACAO DE REFERENCIA (Python/numpy) do campo voxel de um disco mineral.
O mod Java (DepositField.java) implementa EXATAMENTE as mesmas formulas (apenas + - * / sqrt floor,
trigonometria via StrictMath no Java / math no Python) e o mesmo hash splitmix64.
Usado para: estimar o volume real de cada deposito (orcamento de minerio) e validar o Java bloco a bloco.
"""
import math
import numpy as np

M64 = (1 << 64) - 1
C1 = 0xBF58476D1CE4E5B9
C2 = 0x94D049BB133111EB
KX = 0x9E3779B97F4A7C15
KY = 0xC2B2AE3D27D4EB4F
KZ = 0x165667B19E3779F9
EDGE_AMP = 0.30           # amplitude do ruido de borda (fracao do raio normalizado)
EDGE_REACH = 1.0 + EDGE_AMP + 0.01
THICK_AMP = 0.35


def _mix(z):
    z = (z ^ (z >> np.uint64(30))) * np.uint64(C1)
    z = (z ^ (z >> np.uint64(27))) * np.uint64(C2)
    return z ^ (z >> np.uint64(31))


def hash01(seed, x, y, z):
    """seed: int python (signed ok); x,y,z: int arrays/escalares -> float64 em [0,1)"""
    with np.errstate(over="ignore"):
        h = np.uint64(seed & M64)
        h = _mix(h ^ (np.asarray(x).astype(np.int64).astype(np.uint64) * np.uint64(KX)))
        h = _mix(h ^ (np.asarray(y).astype(np.int64).astype(np.uint64) * np.uint64(KY)))
        h = _mix(h ^ (np.asarray(z).astype(np.int64).astype(np.uint64) * np.uint64(KZ)))
        return (h >> np.uint64(11)).astype(np.float64) * (1.0 / 9007199254740992.0)


def vnoise2(seed, a, b):
    """ruido de valor 2D suave em [-1,1]"""
    ia = np.floor(a); ib = np.floor(b)
    fa = a - ia; fb = b - ib
    sa = fa * fa * (3.0 - 2.0 * fa); sb = fb * fb * (3.0 - 2.0 * fb)
    ia = ia.astype(np.int64); ib = ib.astype(np.int64)
    s2 = seed ^ 0x5DEECE66D
    v00 = hash01(s2, ia, 91, ib); v10 = hash01(s2, ia + 1, 91, ib)
    v01 = hash01(s2, ia, 91, ib + 1); v11 = hash01(s2, ia + 1, 91, ib + 1)
    top = v00 * (1.0 - sa) + v10 * sa
    bot = v01 * (1.0 - sa) + v11 * sa
    return 2.0 * (top * (1.0 - sb) + bot * sb) - 1.0


def axes(az_deg, dip_deg):
    az = math.radians(az_deg); dp = math.radians(dip_deg)
    c, s, cd, sd = math.cos(az), math.sin(az), math.cos(dp), math.sin(dp)
    u = (c, 0.0, s)
    v = (-s * cd, -sd, c * cd)
    n = (s * sd, -cd, -c * sd)
    return u, v, n


def disc_bbox(d):
    """caixa (x0,x1,y0,y1,z0,z1) inteira, inclusiva, que contem o disco"""
    u, v, n = axes(d["az"], d["dip"])
    a, b, T, irr = d["a"], d["b"], d["T"], d["irr"]
    hmax = 0.5 * T * (1.0 + THICK_AMP * irr) + 1.0
    out = []
    for k, c in zip(range(3), (d["cx"], d["cy"], d["cz"])):
        e = math.sqrt((EDGE_REACH * a * u[k]) ** 2 + (EDGE_REACH * b * v[k]) ** 2) + hmax * abs(n[k]) + 1.0
        out += [int(math.floor(c - e)), int(math.ceil(c + e))]
    return out


def disc_prob(d, X, Y, Z):
    """probabilidade (0 fora do disco) de bloco (X,Y,Z inteiros, centro +0.5) pertencer ao disco"""
    u, v, n = axes(d["az"], d["dip"])
    px = X + 0.5 - d["cx"]; py = Y + 0.5 - d["cy"]; pz = Z + 0.5 - d["cz"]
    uu = px * u[0] + py * u[1] + pz * u[2]
    vv = px * v[0] + py * v[1] + pz * v[2]
    ww = px * n[0] + py * n[1] + pz * n[2]
    a, b, T, irr, seed = d["a"], d["b"], d["T"], d["irr"], d["seed"]
    ua = uu / a; vb = vv / b
    rn = np.sqrt(ua * ua + vb * vb)
    ls = max(3.0, 0.18 * min(a, b))
    r = rn + irr * EDGE_AMP * vnoise2(seed, uu / ls, vv / ls)
    s = 1.0 - r * r
    inside = (s > 0.0) & (rn < EDGE_REACH)
    s = np.where(inside, s, 0.0)
    ls2 = ls * 1.7
    sq = np.sqrt(s)
    hT = 0.5 * T * (sq * np.sqrt(sq)) * (1.0 + irr * THICK_AMP * vnoise2(seed ^ 0x2545F491, uu / ls2 + 17.3, vv / ls2 - 5.1))
    aw = np.abs(ww)
    ok = inside & (hT > 0.0) & (aw <= hT)
    q = np.where(ok, aw / np.where(hT > 0, hT, 1.0), 0.0)
    f = sq * (1.0 - 0.45 * q * q)
    p = d["conc"] * (0.25 + 0.75 * f)
    return np.where(ok, p, 0.0)


def voxelize_deposit(dep, clip=None):
    """retorna (X,Y,Z,is_assoc) arrays de blocos de minerio do deposito (OR entre discos).
    clip=(x0,x1,z0,z1) opcional (inclusivo) para restringir a um chunk."""
    chunks = []
    for d in dep["discs"]:
        x0, x1, y0, y1, z0, z1 = disc_bbox(d)
        if clip:
            x0 = max(x0, clip[0]); x1 = min(x1, clip[1]); z0 = max(z0, clip[2]); z1 = min(z1, clip[3])
            if x0 > x1 or z0 > z1: continue
        xs = np.arange(x0, x1 + 1); ys = np.arange(y0, y1 + 1); zs = np.arange(z0, z1 + 1)
        for xi in range(0, len(xs), 24):          # fatiar em x para limitar memoria
            xx, yy, zz = np.meshgrid(xs[xi:xi + 24], ys, zs, indexing="ij")
            p = disc_prob(d, xx, yy, zz)
            m = p > 0
            if not m.any(): continue
            px_, py_, pz_ = xx[m], yy[m], zz[m]
            hit = hash01(d["seed"], px_, py_, pz_) < p[m]
            if hit.any(): chunks.append(np.stack([px_[hit], py_[hit], pz_[hit]], 1))
    if not chunks:
        return np.zeros((0, 3), np.int64), np.zeros(0, bool)
    pts = np.unique(np.concatenate(chunks), axis=0)
    af = dep.get("assoc_frac", 0.0)
    if af > 0:
        isa = hash01(dep["discs"][0]["seed"] ^ 0x7A7A7A7A, pts[:, 0], pts[:, 1], pts[:, 2]) < af
    else:
        isa = np.zeros(len(pts), bool)
    return pts, isa
