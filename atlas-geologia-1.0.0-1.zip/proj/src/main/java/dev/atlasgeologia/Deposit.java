package dev.atlasgeologia;

/** Deposito = conjunto de discos conectados/sobrepostos de um mesmo minerio (+ minerio associado opcional). */
public final class Deposit {
    public final int id, ore, assocOre, scale, type, province, minDepth;
    public final double assocFrac;
    public final Disc[] discs;
    public final int minX, maxX, minY, maxY, minZ, maxZ;   // uniao das caixas

    public Deposit(int id, int ore, int assocOre, int scale, int type, int province, int minDepth, double assocFrac, Disc[] discs) {
        this.id = id; this.ore = ore; this.assocOre = assocOre; this.scale = scale; this.type = type;
        this.province = province; this.minDepth = minDepth; this.assocFrac = assocFrac; this.discs = discs;
        int a = Integer.MAX_VALUE, b = Integer.MIN_VALUE, c = Integer.MAX_VALUE, d = Integer.MIN_VALUE, e = Integer.MAX_VALUE, f = Integer.MIN_VALUE;
        for (Disc k : discs) {
            a = Math.min(a, k.x0); b = Math.max(b, k.x1); c = Math.min(c, k.y0); d = Math.max(d, k.y1);
            e = Math.min(e, k.z0); f = Math.max(f, k.z1);
        }
        minX = a; maxX = b; minY = c; maxY = d; minZ = e; maxZ = f;
    }
}
