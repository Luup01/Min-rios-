#!/usr/bin/env bash
# Ordem obrigatoria: analisar mapas -> modelo geologico -> distribuicao -> deposits.json/.bin -> imagens -> dados do mod -> validacao
set -e
cd "$(dirname "$0")"
export ATLAS_INPUT_DIR=${ATLAS_INPUT_DIR:-/mnt/user-data/uploads}
python3 analyze_geology.py
python3 build_deposits.py
python3 render_maps.py
python3 generate_mod_data.py
python3 validate.py
